"""StringLab visual system.

Palette
    page      #E8EDF4  pale cyanotype paper
    ink       #15233F  deep Prussian ink (sidebar, headings, root nodes)
    panel     #FFFFFF
    mark      #F5D547  highlighter — reserved for matches and the Trie path
    kmp       #2B4C8C · rabin–karp #23877C · horspool #8A4A86
Type
    Bricolage Grotesque (headings) · Public Sans (body) · IBM Plex Mono (strings only)
"""

from __future__ import annotations

PALETTE = {
    "page": "#E8EDF4",
    "ink": "#15233F",
    "ink_soft": "#4A5B7A",
    "line": "#C9D3E2",
    "panel": "#FFFFFF",
    "mark": "#F5D547",
    "kmp": "#2B4C8C",
    "rk": "#23877C",
    "bmh": "#8A4A86",
    "danger": "#C2412D",
}

ALGO_COLORS = {
    "KMP": PALETTE["kmp"],
    "Rabin–Karp": PALETTE["rk"],
    "Horspool": PALETTE["bmh"],
}

CSS = """
<style>
@import url('https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,500;12..96,700;12..96,800&family=IBM+Plex+Mono:wght@400;600&family=Public+Sans:wght@400;500;600;700&display=swap');

:root {
  --page:#E8EDF4; --ink:#15233F; --ink-soft:#4A5B7A; --line:#C9D3E2;
  --panel:#FFFFFF; --mark:#F5D547; --mark-deep:#C9A70F;
  --kmp:#2B4C8C; --rk:#23877C; --bmh:#8A4A86; --danger:#C2412D; --ok:#1F7A55;
  --display:'Bricolage Grotesque', 'Public Sans', system-ui, sans-serif;
  --body:'Public Sans', system-ui, -apple-system, 'Segoe UI', sans-serif;
  --mono:'IBM Plex Mono', ui-monospace, 'SFMono-Regular', Menlo, monospace;
}

/* ---- canvas ---------------------------------------------------------- */
.stApp, [data-testid='stAppViewContainer'] { background: var(--page); color: var(--ink); }
html, body, .stApp, .stMarkdown, [data-testid='stMarkdownContainer'], label, input, textarea, button {
  font-family: var(--body);
}
[data-testid='stHeader'] { background: transparent; }
.main .block-container, [data-testid='stMainBlockContainer'] {
  max-width: 1280px; padding: 2.2rem 3rem 4rem;
}
[data-testid='stMarkdownContainer'] p, [data-testid='stMarkdownContainer'] li { color: var(--ink); line-height: 1.6; }
h1, h2, h3, h4 { font-family: var(--display) !important; color: var(--ink) !important; letter-spacing: -0.02em; }
:focus-visible { outline: 3px solid var(--mark-deep) !important; outline-offset: 2px; }

/* ---- sidebar --------------------------------------------------------- */
[data-testid='stSidebar'] { background: var(--ink); border-right: 0; }
[data-testid='stSidebar'] > div:first-child { padding: 1.4rem 1rem; }
[data-testid='stSidebar'] * { color: #DCE4F2; }
[data-testid='stSidebar'] [role='radiogroup'] { gap: 2px; }
[data-testid='stSidebar'] [role='radiogroup'] label {
  padding: .5rem .7rem; border-radius: 6px; margin: 0; width: 100%;
  border-left: 3px solid transparent; transition: background 120ms ease;
}
[data-testid='stSidebar'] [role='radiogroup'] label:hover { background: #22345A; }
[data-testid='stSidebar'] [role='radiogroup'] label:has(input:checked) {
  background: #22345A; border-left-color: var(--mark);
}
[data-testid='stSidebar'] [role='radiogroup'] label:has(input:checked) p { color: #fff; font-weight: 600; }
/* Hide only the radio dot: any wrapper that contains no text. Version-independent. */
[data-testid='stSidebar'] [role='radiogroup'] label > div:not(:has(p)):not(:has(input)),
[data-testid='stSidebar'] [role='radiogroup'] label > div > div:not(:has(p)):not(:has(input)) { display: none !important; }
[data-testid='stSidebar'] [role='radiogroup'] label p,
[data-testid='stSidebar'] [role='radiogroup'] label [data-testid='stMarkdownContainer'] { color: #C9D4E8 !important; display: block !important; visibility: visible !important; }
[data-testid='stSidebar'] [role='radiogroup'] label:has(input:checked) p { color: #fff !important; }
[data-testid='stSidebar'] [data-testid='stMarkdownContainer'] p { color: #C9D4E8; }
[data-testid='stAppDeployButton'] { display: none; }
[data-testid='stSidebar'] [role='radiogroup'] p { font-size: .9rem; }
.sl-brand { display:flex; align-items:center; gap:.7rem; margin-bottom: 1.6rem; }
.sl-brand-mark {
  font-family: var(--mono); font-weight: 600; font-size: 1rem; color: var(--ink) !important;
  background: var(--mark); padding: .3rem .45rem; border-radius: 3px; line-height: 1;
}
.sl-brand-name { font-family: var(--display); font-weight: 800; font-size: 1.15rem; color: #fff !important; letter-spacing: -0.01em; }
.sl-brand-sub { font-size: .74rem; color: #93A3C0 !important; margin-top: 2px; }
.sl-side-note { margin-top: 1.6rem; padding-top: 1rem; border-top: 1px solid #2C3F66; font-size: .78rem; line-height: 1.55; }
.sl-side-note b { color: #fff !important; font-weight: 600; }
.sl-side-note span { color: #93A3C0 !important; }

/* ---- page header ----------------------------------------------------- */
.sl-head { margin: 0 0 1.6rem; max-width: 760px; }
.sl-head h1 { font-size: 2.35rem; line-height: 1.08; font-weight: 800; margin: 0 0 .5rem; padding: 0; }
.sl-head p { color: var(--ink-soft) !important; font-size: 1.02rem; margin: 0; max-width: 64ch; }

.sl-h2 { font-family: var(--display); font-size: 1.25rem; font-weight: 700; color: var(--ink); margin: 2rem 0 .35rem; letter-spacing: -0.01em; }
.sl-h2 + .sl-sub { margin-top: 0; }
.sl-sub { color: var(--ink-soft); font-size: .9rem; margin: 0 0 .9rem; max-width: 72ch; }
.sl-muted { color: var(--ink-soft); font-size: .88rem; }

/* ---- hero ------------------------------------------------------------ */
.sl-hero { display:grid; grid-template-columns: minmax(0, 1.05fr) minmax(0, 1fr); gap: 2.6rem; align-items: center; margin-bottom: 1rem; }
.sl-hero h1 { font-family: var(--display); font-weight: 800; font-size: clamp(2.3rem, 4.4vw, 3.5rem); line-height: 1.02; letter-spacing: -0.035em; color: var(--ink); margin: 0 0 1rem; }
.sl-hero p.lede { font-size: 1.08rem; color: var(--ink-soft); max-width: 46ch; line-height: 1.6; }
.sl-specimen { background: var(--panel); border-radius: 10px; padding: 1.2rem 1.3rem 1rem; box-shadow: 0 1px 0 var(--line), 0 18px 40px -24px rgba(21,35,63,.35); }
.sl-specimen-q { font-family: var(--mono); font-size: .82rem; color: var(--ink-soft); margin-bottom: .6rem; }
.sl-specimen-q b { color: var(--ink); background: var(--mark); padding: 0 .25rem; border-radius: 2px; }
.sl-lanes { display:grid; gap:.35rem; margin-top: .9rem; }
.sl-lane { display:grid; grid-template-columns: 96px 1fr auto; gap: .7rem; align-items:center; font-size: .82rem; }
.sl-lane-name { font-weight: 600; }
.sl-lane-bar { height: 8px; border-radius: 4px; background: #EEF2F8; overflow: hidden; }
.sl-lane-bar i { display:block; height: 100%; border-radius: 4px; transform-origin: left; animation: sl-grow 900ms cubic-bezier(.2,.7,.2,1) both; }
.sl-lane-num { font-family: var(--mono); font-size: .78rem; color: var(--ink-soft); }
@keyframes sl-grow { from { transform: scaleX(0); } to { transform: scaleX(1); } }
@media (prefers-reduced-motion: reduce) { .sl-lane-bar i { animation: none; } }

/* ---- text strip / highlighter --------------------------------------- */
.sl-strip { font-family: var(--mono); font-size: .86rem; line-height: 1.85; color: var(--ink); white-space: pre-wrap; word-break: break-word; }
.sl-mark, .search-highlight {
  background: linear-gradient(transparent 12%, var(--mark) 12%, var(--mark) 88%, transparent 88%) !important;
  color: var(--ink) !important; padding: 0 2px !important; border-radius: 2px; font-weight: 600;
}
.sl-mark { position: relative; }
.sl-mark::after { content: attr(data-pos); position: absolute; left: 0; top: -1.15em; font-size: .62rem; color: var(--ink-soft); font-weight: 400; }

/* ---- stat row (not cards) ------------------------------------------- */
.sl-stats { display:flex; flex-wrap: wrap; gap: 0; border-top: 1px solid var(--line); border-bottom: 1px solid var(--line); margin: 1.2rem 0 .4rem; }
.sl-stat { flex: 1 1 140px; padding: .9rem 1.1rem .85rem 0; }
.sl-stat + .sl-stat { padding-left: 1.1rem; border-left: 1px solid var(--line); }
.sl-stat b { display:block; font-family: var(--display); font-size: 1.65rem; font-weight: 700; color: var(--ink); letter-spacing: -0.02em; line-height: 1.1; }
.sl-stat span { font-size: .8rem; color: var(--ink-soft); }

/* ---- panels ---------------------------------------------------------- */
.sl-panel { background: var(--panel); border-radius: 10px; padding: 1.1rem 1.25rem; box-shadow: 0 1px 0 var(--line); }
.sl-diagram { background: var(--panel); border-radius: 10px; padding: 1rem .8rem; box-shadow: 0 1px 0 var(--line); }
[data-testid='stSidebar'] [data-testid='stVerticalBlockBorderWrapper'],
[data-testid='stSidebar'] [data-testid='stVerticalBlock'] { background: transparent !important; }
[data-testid='stDecoration'] { display: none; }

/* ---- result list ----------------------------------------------------- */
.sl-result { background: var(--panel); border-radius: 10px; padding: 1rem 1.2rem 1.1rem; margin: 0 0 .8rem; box-shadow: 0 1px 0 var(--line); border-left: 4px solid var(--ink); }
.sl-result-top { display:flex; justify-content: space-between; align-items: baseline; gap: 1rem; flex-wrap: wrap; }
.sl-result-name { font-family: var(--display); font-weight: 700; font-size: 1.08rem; color: var(--ink); }
.sl-result-meta { font-size: .8rem; color: var(--ink-soft); }
.sl-score { font-family: var(--mono); font-size: .8rem; color: var(--ink); }
.sl-scorebar { height: 4px; background: #EEF2F8; border-radius: 2px; margin: .55rem 0 .7rem; }
.sl-scorebar i { display:block; height: 100%; background: var(--ink); border-radius: 2px; }
.sl-context { font-size: .9rem; line-height: 1.65; color: var(--ink); padding: .45rem 0; border-top: 1px dashed var(--line); }
.sl-algos { display:flex; gap: 1.4rem; flex-wrap: wrap; margin-top: .6rem; font-size: .8rem; color: var(--ink-soft); }
.sl-algos b { font-family: var(--mono); font-weight: 600; color: var(--ink); }
.sl-dot { display:inline-block; width: 9px; height: 9px; border-radius: 50%; margin-right: 6px; vertical-align: 0; }

/* ---- chips & badges -------------------------------------------------- */
.sl-chip { display:inline-flex; align-items: baseline; gap: .4rem; font-family: var(--mono); font-size: .86rem; background: var(--panel); color: var(--ink); border: 1px solid var(--line); border-radius: 999px; padding: .28rem .7rem; margin: 0 .35rem .45rem 0; }
.sl-chip small { font-family: var(--body); font-size: .72rem; color: var(--ink-soft); }
.sl-verdict { display:inline-flex; align-items:center; gap:.5rem; font-weight: 600; font-size: .88rem; padding: .4rem .75rem; border-radius: 6px; }
.sl-verdict.ok { background: #E1F1E9; color: var(--ok); }
.sl-verdict.bad { background: #F8E3DF; color: var(--danger); }
.sl-verdict.neutral { background: #E9EEF6; color: var(--ink-soft); }
.sl-legend { display:flex; gap: 1.4rem; flex-wrap: wrap; font-size: .8rem; color: var(--ink-soft); margin: .6rem 0 0; }
.sl-legend span { display:inline-flex; align-items:center; gap: .4rem; }

/* ---- complexity table ------------------------------------------------ */
.sl-table { width:100%; border-collapse: collapse; font-size: .88rem; background: var(--panel); border-radius: 10px; overflow: hidden; box-shadow: 0 1px 0 var(--line); }
.sl-table th { text-align:left; font-weight: 600; color: var(--ink-soft); font-size: .8rem; padding: .7rem 1rem; border-bottom: 1px solid var(--line); }
.sl-table td { padding: .7rem 1rem; border-bottom: 1px solid #EEF2F8; color: var(--ink); vertical-align: top; }
.sl-table td code { font-family: var(--mono); font-size: .82rem; background: transparent; color: var(--ink); padding: 0; }
.sl-table tr:last-child td { border-bottom: 0; }

/* ---- streamlit widgets ---------------------------------------------- */
div.stButton > button, div[data-testid='stFormSubmitButton'] button, div[data-testid='stDownloadButton'] button {
  background: var(--ink); color: #fff; border: 1px solid var(--ink); border-radius: 6px; font-weight: 600; padding: .5rem 1.05rem; min-height: 40px;
}
div.stButton > button:hover, div[data-testid='stFormSubmitButton'] button:hover, div[data-testid='stDownloadButton'] button:hover { background: #22345A; color: #fff; }
div.stButton > button p, div[data-testid='stFormSubmitButton'] button p, div[data-testid='stDownloadButton'] button p { color: #fff; }
div.stButton > button[kind='secondary'] { background: var(--panel); color: var(--ink); border: 1px solid var(--line); }
div.stButton > button[kind='secondary']:hover { background: #F3F6FB; border-color: var(--ink-soft); }
div.stButton > button[kind='secondary'] p { color: var(--ink); }
[data-baseweb='input'], [data-baseweb='textarea'], [data-baseweb='select'] > div { border-radius: 6px !important; background: var(--panel) !important; border-color: var(--line) !important; }
[data-testid='stTextInput'] input { font-family: var(--mono); font-size: .98rem; }
[data-testid='stMetric'] { background: transparent; }
[data-testid='stMetricValue'] { font-family: var(--display); color: var(--ink); }
[data-testid='stDataFrame'] { border-radius: 8px; overflow: hidden; }
[data-testid='stExpander'] { background: var(--panel); border-radius: 8px; border-color: var(--line); }
[data-testid='stTabs'] [data-baseweb='tab'] { font-weight: 600; }
[data-testid='stTabs'] [aria-selected='true'] { color: var(--ink); }
[data-testid='stTabs'] [data-baseweb='tab-highlight'] { background: var(--mark-deep); }

@media (max-width: 900px) {
  .main .block-container, [data-testid='stMainBlockContainer'] { padding: 1.2rem 1rem 3rem; }
  .sl-hero { grid-template-columns: 1fr; gap: 1.4rem; }
  .sl-head h1 { font-size: 1.8rem; }
  .sl-stat + .sl-stat { border-left: 0; padding-left: 0; }
}
</style>
"""
