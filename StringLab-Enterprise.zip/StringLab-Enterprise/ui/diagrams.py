"""Pure-Python SVG diagram renderers (no Graphviz or JS required).

Every function returns a self-contained ``<svg>`` string that can be passed
to ``st.html``. Colours follow the StringLab palette defined in ``ui.theme``.
"""

from __future__ import annotations

from html import escape
from typing import Any

INK = "#15233F"
INK_SOFT = "#4A5B7A"
LINE = "#C9D3E2"
PAPER = "#FFFFFF"
PAGE = "#E8EDF4"
MARK = "#F5D547"
MARK_DEEP = "#C9A70F"
KMP = "#2B4C8C"
RK = "#23877C"
BMH = "#8A4A86"

FONT = "'Public Sans', system-ui, sans-serif"
MONO = "'IBM Plex Mono', ui-monospace, monospace"


def _wrap(svg: str, min_width: int) -> str:
    return (
        f'<div class="sl-diagram" style="overflow-x:auto;max-width:100%">'
        f'<div style="min-width:{min_width}px">{svg}</div></div>'
    )


# --------------------------------------------------------------------------- #
# Generic tidy-tree layout (used by the Trie and Aho–Corasick diagrams)
# --------------------------------------------------------------------------- #
def _layout(tree: dict[str, Any]) -> list[dict[str, Any]]:
    """Assign x (leaf order, parents centred) and depth to every node."""
    nodes: list[dict[str, Any]] = []
    cursor = [0.0]

    def visit(node: dict[str, Any], depth: int, parent: dict[str, Any] | None) -> float:
        node["_depth"] = depth
        node["_parent"] = parent
        nodes.append(node)
        children = node.get("children", [])
        stub = 1 if node.get("hidden") else 0
        if not children:
            x = cursor[0]
            cursor[0] += 1 + 0.6 * stub
            node["_x"] = x
            return x
        xs = [visit(child, depth + 1, node) for child in children]
        if stub:
            node["_stub_x"] = cursor[0]
            cursor[0] += 0.8
            xs.append(node["_stub_x"])
        node["_x"] = (xs[0] + xs[-1]) / 2 if not stub else (xs[0] + xs[-2]) / 2
        return node["_x"]

    visit(tree, 0, None)
    return nodes


def trie_svg(tree: dict[str, Any], prefix: str = "") -> str:
    """Render a Trie subtree. The prefix path is drawn with the highlighter."""
    nodes = _layout(tree)
    gap_x, gap_y, radius, pad = 46, 78, 16, 40
    max_x = max(max(n["_x"], n.get("_stub_x", 0)) for n in nodes)
    max_depth = max(n["_depth"] for n in nodes)
    width = int(pad * 2 + 70 + max_x * gap_x + radius * 2)
    height = int(pad * 2 + max_depth * gap_y + 50)

    def pos(node: dict[str, Any]) -> tuple[float, float]:
        return pad + 70 + node["_x"] * gap_x + radius, pad + node["_depth"] * gap_y

    parts: list[str] = []
    # depth rails
    for depth in range(max_depth + 1):
        y = pad + depth * gap_y
        parts.append(
            f'<line x1="{pad + 52}" y1="{y}" x2="{width - pad / 2}" y2="{y}" stroke="{LINE}" stroke-dasharray="2 6"/>'
            f'<text x="{pad - 6}" y="{y + 4}" font-family="{FONT}" font-size="11" fill="{INK_SOFT}">'
            f'{"root" if depth == 0 else f"depth {depth}"}</text>'
        )
    # edges first
    for node in nodes:
        parent = node["_parent"]
        if parent is None:
            continue
        x1, y1 = pos(parent)
        x2, y2 = pos(node)
        on_path = node["on_path"] and parent["on_path"]
        mid = (y1 + y2) / 2
        d = f"M{x1},{y1 + radius} C{x1},{mid} {x2},{mid} {x2},{y2 - radius}"
        if on_path:
            parts.append(f'<path d="{d}" fill="none" stroke="{MARK}" stroke-width="9" stroke-linecap="round" opacity=".85"/>')
        parts.append(f'<path d="{d}" fill="none" stroke="{INK if on_path else "#9AA9C0"}" stroke-width="{2 if on_path else 1.3}"/>')
    # hidden-branch stubs
    for node in nodes:
        if node.get("hidden"):
            x1, y1 = pos(node)
            sx = pad + 70 + node.get("_stub_x", node["_x"] + 0.7) * gap_x + radius
            sy = y1 + gap_y * 0.62
            parts.append(
                f'<path d="M{x1},{y1 + radius} L{sx},{sy - 10}" stroke="#9AA9C0" stroke-dasharray="3 4" fill="none"/>'
                f'<rect x="{sx - 17}" y="{sy - 10}" width="34" height="20" rx="10" fill="{PAGE}" stroke="{LINE}"/>'
                f'<text x="{sx}" y="{sy + 4}" text-anchor="middle" font-family="{FONT}" font-size="10.5" fill="{INK_SOFT}">+{node["hidden"]}</text>'
            )
    # nodes
    for node in nodes:
        x, y = pos(node)
        on_path = node["on_path"] and node["_depth"] > 0
        is_root = node["_depth"] == 0
        fill = MARK if on_path else (INK if is_root else PAPER)
        stroke = INK
        text_fill = PAPER if is_root else INK
        title = escape(
            f'"{node["word"]}" · {node["prefix_count"]} word(s) below'
            + (f' · whole word, seen {node["frequency"]}×' if node["end"] else "")
        )
        parts.append(f'<g><title>{title}</title>')
        if node["end"]:
            parts.append(f'<circle cx="{x}" cy="{y}" r="{radius + 4}" fill="none" stroke="{stroke}" stroke-width="1.4"/>')
        parts.append(
            f'<circle cx="{x}" cy="{y}" r="{radius}" fill="{fill}" stroke="{stroke}" stroke-width="{1.8 if on_path else 1.3}"/>'
            f'<text x="{x}" y="{y + 5}" text-anchor="middle" font-family="{MONO}" font-size="{12 if is_root else 15}" '
            f'font-weight="600" fill="{text_fill}">{escape(node["label"])}</text>'
        )
        if node["end"] and not is_root:
            parts.append(
                f'<text x="{x}" y="{y + radius + 18}" text-anchor="middle" font-family="{FONT}" font-size="10" '
                f'fill="{INK_SOFT}">{escape(node["word"])}</text>'
            )
        parts.append("</g>")

    svg = (
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} {height}" width="{width}" height="{height}" '
        f'role="img" aria-label="Trie diagram for prefix {escape(prefix)}">'
        + "".join(parts)
        + "</svg>"
    )
    return _wrap(svg, width)


def trie_legend() -> str:
    return (
        '<div class="sl-legend">'
        f'<span><svg width="22" height="22"><circle cx="11" cy="11" r="8" fill="{MARK}" stroke="{INK}"/></svg>Your prefix path</span>'
        f'<span><svg width="26" height="26"><circle cx="13" cy="13" r="7" fill="#fff" stroke="{INK}"/>'
        f'<circle cx="13" cy="13" r="11" fill="none" stroke="{INK}"/></svg>Ends a whole word</span>'
        f'<span><svg width="34" height="20"><rect x="1" y="2" width="32" height="16" rx="8" fill="{PAGE}" stroke="{LINE}"/>'
        f'<text x="17" y="14" text-anchor="middle" font-size="9" fill="{INK_SOFT}">+n</text></svg>Branches not drawn</span>'
        "</div>"
    )


# --------------------------------------------------------------------------- #
# Aho–Corasick automaton
# --------------------------------------------------------------------------- #
def aho_corasick_svg(automaton: Any, max_states: int = 60) -> str:
    """Draw goto edges as a tree and failure links as dashed arcs."""
    if automaton.state_count > max_states:
        return (
            f'<p class="sl-muted">The automaton has {automaton.state_count} states — '
            f"too many to draw clearly. Try fewer or shorter patterns.</p>"
        )
    def build(state: int, label: str) -> dict[str, Any]:
        return {
            "state": state,
            "label": label,
            "children": [build(child, ch) for ch, child in sorted(automaton.goto[state].items())],
            "hidden": 0,
        }

    tree = build(0, "0")
    nodes = _layout(tree)
    by_state = {n["state"]: n for n in nodes}
    gap_x, gap_y, radius, pad = 92, 66, 16, 36
    max_row = max(n["_x"] for n in nodes)
    max_depth = max(n["_depth"] for n in nodes)
    width = int(pad * 2 + max_depth * gap_x + radius * 2 + 90)
    height = int(pad * 2 + max_row * gap_y + 110)

    def pos(n: dict[str, Any]) -> tuple[float, float]:
        # Left-to-right: depth on x, sibling order on y — each pattern reads as a row.
        return pad + radius + n["_depth"] * gap_x, pad + 40 + n["_x"] * gap_y

    parts = [
        f'<defs><marker id="ac-arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto">'
        f'<path d="M0,0 L10,5 L0,10 z" fill="{RK}"/></marker>'
        f'<marker id="ac-goto" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto">'
        f'<path d="M0,0 L10,5 L0,10 z" fill="{INK}"/></marker></defs>'
    ]
    for n in nodes:
        if n["_parent"] is None:
            continue
        x1, y1 = pos(n["_parent"])
        x2, y2 = pos(n)
        d = f"M{x1 + radius},{y1} C{x1 + gap_x * .55},{y1} {x2 - gap_x * .55},{y2} {x2 - radius - 2},{y2}"
        parts.append(f'<path d="{d}" fill="none" stroke="{INK}" stroke-width="1.4" marker-end="url(#ac-goto)"/>')
        parts.append(
            f'<rect x="{x2 - gap_x / 2 - 8}" y="{y2 - 9}" width="16" height="18" rx="3" fill="{PAPER}"/>'
            f'<text x="{x2 - gap_x / 2}" y="{y2 + 5}" text-anchor="middle" font-family="{MONO}" font-size="13" '
            f'fill="{INK}" font-weight="600">{escape(n["label"])}</text>'
        )
    for state, target in enumerate(automaton.fail):
        if state == 0 or target == 0:
            continue
        x1, y1 = pos(by_state[state])
        x2, y2 = pos(by_state[target])
        lift = 26 + abs(y2 - y1) * 0.15 + abs(x2 - x1) * 0.12
        cx = (x1 + x2) / 2
        cy = min(y1, y2) - lift if y2 <= y1 else max(y1, y2) + lift
        sy = y1 - radius if y2 <= y1 else y1 + radius
        ey = y2 - radius - 1 if y2 <= y1 else y2 + radius + 1
        parts.append(
            f'<path d="M{x1},{sy} Q{cx},{cy} {x2},{ey}" fill="none" stroke="{RK}" stroke-width="1.3" '
            f'stroke-dasharray="5 4" marker-end="url(#ac-arrow)" opacity=".9"/>'
        )
    for n in nodes:
        x, y = pos(n)
        accepting = bool(automaton.output[n["state"]])
        fill = MARK if accepting else (INK if n["state"] == 0 else PAPER)
        txt = PAPER if n["state"] == 0 else INK
        emits = [automaton.patterns[i] for i in automaton.output[n["state"]]]
        parts.append(f'<g><title>state {n["state"]} · emits: {escape(", ".join(emits) or "nothing")}</title>')
        if accepting:
            parts.append(f'<circle cx="{x}" cy="{y}" r="{radius + 4}" fill="none" stroke="{INK}"/>')
        parts.append(
            f'<circle cx="{x}" cy="{y}" r="{radius}" fill="{fill}" stroke="{INK}" stroke-width="1.3"/>'
            f'<text x="{x}" y="{y + 4}" text-anchor="middle" font-family="{FONT}" font-size="11" fill="{txt}">{n["state"]}</text></g>'
        )
        if accepting:
            leaf = not n["children"]
            lx, anchor, ly = (x + radius + 10, "start", y + 4) if leaf else (x, "middle", y + radius + 17)
            parts.append(
                f'<text x="{lx}" y="{ly}" text-anchor="{anchor}" font-family="{MONO}" font-size="11" '
                f'fill="{INK_SOFT}">{escape(" + ".join(emits))}</text>'
            )
    svg = (
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} {height}" width="{width}" height="{height}" '
        f'role="img" aria-label="Aho–Corasick automaton">' + "".join(parts) + "</svg>"
    )
    return _wrap(svg, width)


# --------------------------------------------------------------------------- #
# KMP LPS table and Horspool shift table
# --------------------------------------------------------------------------- #
def lps_svg(pattern: str, lps: list[int]) -> str:
    cell, pad = 38, 8
    pattern = pattern[:40]
    lps = lps[:40]
    width = pad * 2 + 70 + cell * len(pattern)
    height = 132
    parts = []
    for label, y in (("index", 22), ("char", 54), ("LPS", 96)):
        parts.append(f'<text x="{pad}" y="{y + 5}" font-family="{FONT}" font-size="11" fill="{INK_SOFT}">{label}</text>')
    for i, (ch, value) in enumerate(zip(pattern, lps)):
        x = pad + 70 + i * cell
        parts.append(f'<text x="{x + cell / 2}" y="27" text-anchor="middle" font-family="{MONO}" font-size="10" fill="{INK_SOFT}">{i}</text>')
        parts.append(
            f'<rect x="{x + 1}" y="36" width="{cell - 2}" height="34" rx="4" fill="{PAPER}" stroke="{LINE}"/>'
            f'<text x="{x + cell / 2}" y="59" text-anchor="middle" font-family="{MONO}" font-size="15" font-weight="600" fill="{INK}">'
            f'{escape(ch) if ch != " " else "␣"}</text>'
        )
        fill = KMP if value else PAGE
        parts.append(
            f'<rect x="{x + 1}" y="80" width="{cell - 2}" height="32" rx="4" fill="{fill}" opacity="{0.25 + 0.75 * min(1, value / max(1, max(lps)))}"/>'
            f'<text x="{x + cell / 2}" y="101" text-anchor="middle" font-family="{MONO}" font-size="14" font-weight="600" '
            f'fill="{PAPER if value else INK_SOFT}">{value}</text>'
        )
    svg = f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} {height}" width="{width}" height="{height}" role="img" aria-label="KMP LPS table">{"".join(parts)}</svg>'
    return _wrap(svg, width)


def shift_table_svg(pattern: str, table: dict[str, int]) -> str:
    items = sorted(table.items(), key=lambda kv: kv[1])[:24] + [("other", len(pattern))]
    cell, pad = 46, 8
    width = pad * 2 + 70 + cell * len(items)
    parts = [
        f'<text x="{pad}" y="34" font-family="{FONT}" font-size="11" fill="{INK_SOFT}">char</text>',
        f'<text x="{pad}" y="76" font-family="{FONT}" font-size="11" fill="{INK_SOFT}">shift</text>',
    ]
    longest = max(v for _, v in items)
    for i, (ch, value) in enumerate(items):
        x = pad + 70 + i * cell
        label = "␣" if ch == " " else ("*" if ch == "other" else escape(ch))
        parts.append(
            f'<rect x="{x + 1}" y="12" width="{cell - 2}" height="34" rx="4" fill="{PAPER}" stroke="{LINE}"/>'
            f'<text x="{x + cell / 2}" y="35" text-anchor="middle" font-family="{MONO}" font-size="15" font-weight="600" fill="{INK}">{label}</text>'
            f'<rect x="{x + 1}" y="54" width="{cell - 2}" height="32" rx="4" fill="{BMH}" opacity="{0.25 + 0.75 * value / longest}"/>'
            f'<text x="{x + cell / 2}" y="75" text-anchor="middle" font-family="{MONO}" font-size="14" font-weight="600" fill="{PAPER}">{value}</text>'
        )
    svg = f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} 96" width="{width}" height="96" role="img" aria-label="Horspool shift table">{"".join(parts)}</svg>'
    return _wrap(svg, width)


# --------------------------------------------------------------------------- #
# Bloom filter bit strip
# --------------------------------------------------------------------------- #
def bloom_svg(bit_array: list[bool], probes: list[int], present: bool) -> str:
    width, height, pad = 900, 140, 16
    buckets = 180
    size = len(bit_array)
    per = size / buckets
    bar_w = (width - pad * 2) / buckets
    parts = []
    for b in range(buckets):
        lo, hi = int(b * per), max(int((b + 1) * per), int(b * per) + 1)
        density = sum(bit_array[lo:hi]) / (hi - lo)
        parts.append(
            f'<rect x="{pad + b * bar_w}" y="38" width="{bar_w - 0.6}" height="34" fill="{KMP}" opacity="{0.08 + 0.85 * density:.2f}"/>'
        )
    for index in probes:
        x = pad + index / size * (width - pad * 2)
        hit = bit_array[index]
        color = INK if hit else "#C2412D"
        parts.append(
            f'<line x1="{x}" y1="24" x2="{x}" y2="84" stroke="{color}" stroke-width="2"/>'
            f'<circle cx="{x}" cy="24" r="5" fill="{MARK if hit else PAPER}" stroke="{color}" stroke-width="1.6"/>'
        )
    for row, index in enumerate(sorted(probes)):
        x = pad + index / size * (width - pad * 2)
        color = INK if bit_array[index] else "#C2412D"
        y = 98 + (row % 3) * 13
        parts.append(
            f'<line x1="{x}" y1="84" x2="{x}" y2="{y - 9}" stroke="{color}" stroke-width=".8" opacity=".5"/>'
            f'<text x="{x}" y="{y}" text-anchor="middle" font-family="{MONO}" font-size="10" fill="{color}">{index}</text>'
        )
    parts.append(
        f'<text x="{pad}" y="14" font-family="{FONT}" font-size="11" fill="{INK_SOFT}">bit 0</text>'
        f'<text x="{width - pad}" y="14" text-anchor="end" font-family="{FONT}" font-size="11" fill="{INK_SOFT}">bit {size - 1:,}</text>'
    )
    svg = (
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} {height}" width="100%" role="img" '
        f'aria-label="Bloom filter bit positions; term {"possibly present" if present else "definitely absent"}">{"".join(parts)}</svg>'
    )
    return f'<div class="sl-diagram">{svg}</div>'


# --------------------------------------------------------------------------- #
# Architecture diagram
# --------------------------------------------------------------------------- #
def architecture_svg() -> str:
    """System architecture: ingestion → indexes → query pipeline → evidence."""
    W, H = 1040, 480

    def box(x, y, w, h, title, sub="", fill=PAPER, stroke=INK, tfill=INK, mark=False):
        out = []
        if mark:
            out.append(f'<rect x="{x - 3}" y="{y + h - 12}" width="{w + 6}" height="14" fill="{MARK}" opacity=".9"/>')
        out.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="8" fill="{fill}" stroke="{stroke}" stroke-width="1.3"/>')
        out.append(f'<text x="{x + 14}" y="{y + 25}" font-family="{FONT}" font-size="14" font-weight="700" fill="{tfill}">{title}</text>')
        for i, line in enumerate(sub.split("|") if sub else []):
            out.append(f'<text x="{x + 14}" y="{y + 45 + i * 16}" font-family="{FONT}" font-size="11.5" fill="{INK_SOFT if tfill == INK else "#C8D3E6"}">{line}</text>')
        return "".join(out)

    def arrow(x1, y1, x2, y2, color=INK, dash=""):
        return (
            f'<path d="M{x1},{y1} C{(x1 + x2) / 2},{y1} {(x1 + x2) / 2},{y2} {x2},{y2}" fill="none" stroke="{color}" '
            f'stroke-width="1.5" {f"stroke-dasharray={dash!r}" if dash else ""} marker-end="url(#arch-arrow)"/>'
        )

    def line(points, color=INK, dash="", head=True, width=1.5):
        d = "M" + " L".join(f"{x},{y}" for x, y in points)
        return (f'<path d="{d}" fill="none" stroke="{color}" stroke-width="{width}" stroke-linejoin="round" '
                f'{f"stroke-dasharray={dash!r}" if dash else ""} {"marker-end=" + repr("url(#arch-arrow)") if head else ""}/>')

    def label(x, y, text, anchor="start", color=INK_SOFT, size=11.5):
        return f'<text x="{x}" y="{y}" text-anchor="{anchor}" font-family="{FONT}" font-size="{size}" fill="{color}">{text}</text>'

    p = [
        f'<defs><marker id="arch-arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto">'
        f'<path d="M0,0 L10,5 L0,10 z" fill="{INK}"/></marker></defs>',
        label(20, 20, "Build time: once per document", size=12),
        label(20, 268, "Query time: every search", size=12),
        f'<line x1="20" y1="244" x2="{W - 20}" y2="244" stroke="{LINE}" stroke-dasharray="3 5"/>',
        # build lane
        box(20, 60, 170, 92, "Ingestion", "TXT · PDF · DOCX|10 MiB / 500-page guard|SHA-256 de-duplication"),
        box(240, 60, 170, 92, "Text processing", "casefold normalisation|Unicode word tokens|term frequencies"),
        box(470, 50, 190, 50, "Trie", "weighted by frequency"),
        box(470, 112, 190, 50, "Bloom filter", "k hashes over m bits"),
        box(470, 174, 190, 50, "BM25 inverted index", "term → {doc: tf}"),
        box(820, 60, 190, 92, "SQLite store", "documents + digests|search history|metadata only", fill=INK, stroke=INK, tfill=PAPER),
        line([(190, 106), (238, 106)]),
        arrow(410, 106, 470, 75), arrow(410, 106, 470, 137), arrow(410, 106, 470, 199),
        line([(105, 60), (105, 38), (915, 38), (915, 58)], INK_SOFT, "4 4"),
        label(500, 33, "raw text persisted", "middle"),
        # index bus into query lane
        f'<rect x="676" y="50" width="10" height="174" rx="3" fill="{PAGE}" stroke="{LINE}"/>',
        line([(660, 75), (676, 75)], LINE, head=False), line([(660, 137), (676, 137)], LINE, head=False),
        line([(660, 199), (676, 199)], LINE, head=False),
        line([(681, 224), (681, 282), (275, 282), (275, 298)], INK_SOFT, "4 4"),
        line([(460, 282), (460, 298)], INK_SOFT, "4 4"),
        line([(681, 282), (681, 384), (285, 384), (285, 400)], INK_SOFT, "4 4"),
        line([(520, 384), (520, 400)], INK_SOFT, "4 4"),
        label(690, 276, "indexes read at query time"),
        # query lane
        box(20, 300, 140, 70, "Query", "normalise · tokenise"),
        box(200, 300, 150, 70, "Bloom screen", "absent → stop early|+ did-you-mean"),
        box(390, 300, 140, 70, "BM25 rank", "order candidates"),
        box(570, 288, 210, 94, "Exact verification", "KMP · prefix function|Rabin–Karp · rolling hash|Horspool · bad-char skip", mark=True),
        box(820, 300, 190, 70, "Evidence", "highlights · positions|3-way agreement · metrics"),
        line([(160, 335), (198, 335)]), line([(350, 335), (388, 335)]), line([(530, 335), (568, 335)]),
        line([(780, 335), (818, 335)]),
        line([(965, 300), (965, 154)], INK_SOFT, "4 4"),
        label(957, 232, "query logged", "end"),
        # tools
        box(200, 402, 170, 58, "Trie explorer", "top-k · fuzzy Levenshtein"),
        box(420, 402, 200, 58, "Multi-pattern scan", "Aho–Corasick automaton"),
        box(670, 402, 190, 58, "Benchmark lab", "median timings · CSV export"),
        label(20, 436, "Tools on the"),
        label(20, 452, "same indexes"),
    ]
    svg = (
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}" role="img" '
        f'aria-label="StringLab system architecture">' + "".join(p) + "</svg>"
    )
    return _wrap(svg, W)


def highlight_strip(text: str, positions: list[int], length: int, limit: int = 420) -> str:
    """Render a text excerpt with highlighter marks and position ticks."""
    if positions:
        start = max(0, positions[0] - 60)
    else:
        start = 0
    excerpt_end = min(len(text), start + limit)
    out: list[str] = []
    cursor = start
    for position in positions:
        if position < cursor or position >= excerpt_end:
            continue
        out.append(escape(text[cursor:position]))
        out.append(
            f'<mark class="sl-mark" data-pos="{position}">{escape(text[position:position + length])}</mark>'
        )
        cursor = position + length
    out.append(escape(text[cursor:excerpt_end]))
    lead = "…" if start else ""
    tail = "…" if excerpt_end < len(text) else ""
    return f'<div class="sl-strip">{lead}{"".join(out)}{tail}</div>'
