"""Tests for the advanced retrieval models: Horspool, Aho–Corasick, BM25, ranked/fuzzy Trie."""

import random

import pytest

from algorithms.aho_corasick import AhoCorasick
from algorithms.boyer_moore import build_shift_table, horspool_search
from algorithms.kmp import kmp_search
from algorithms.trie import Trie
from core.ranking import BM25Index
from core.search_engine import SearchEngine


def brute_force(text: str, pattern: str) -> list[int]:
    if not pattern:
        return []
    return [i for i in range(len(text) - len(pattern) + 1) if text[i:i + len(pattern)] == pattern]


def levenshtein(a: str, b: str) -> int:
    row = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        prev, row[0] = row[0], i
        for j, cb in enumerate(b, 1):
            prev, row[j] = row[j], min(row[j] + 1, row[j - 1] + 1, prev + (ca != cb))
    return row[-1]


# --- Boyer–Moore–Horspool -------------------------------------------------
def test_horspool_matches_brute_force_on_random_inputs() -> None:
    rng = random.Random(7)
    for _ in range(300):
        text = "".join(rng.choice("abc") for _ in range(rng.randint(0, 60)))
        pattern = "".join(rng.choice("abc") for _ in range(rng.randint(1, 5)))
        assert horspool_search(text, pattern)["positions"] == brute_force(text, pattern)


def test_horspool_finds_overlapping_matches_and_skips_windows() -> None:
    assert horspool_search("aaaaa", "aa")["positions"] == [0, 1, 2, 3]
    result = horspool_search("x" * 1000 + "needle", "needle")
    assert result["positions"] == [1000]
    assert result["windows"] < 300  # sub-linear window count on long misses


def test_horspool_shift_table_and_edge_cases() -> None:
    assert build_shift_table("abcab") == {"a": 1, "b": 3, "c": 2}
    assert horspool_search("", "a")["positions"] == []
    assert horspool_search("abc", "")["positions"] == []
    with pytest.raises(TypeError):
        horspool_search(1, "a")  # type: ignore[arg-type]


# --- Aho–Corasick ---------------------------------------------------------
def test_aho_corasick_reports_all_patterns_like_brute_force() -> None:
    patterns = ["he", "she", "his", "hers"]
    text = "ushers and his sheep heard her"
    result = AhoCorasick(patterns).search(text)
    for pattern in patterns:
        assert result["matches"][pattern] == brute_force(text, pattern)
    assert result["transitions"] == len(text)


def test_aho_corasick_random_cross_check() -> None:
    rng = random.Random(11)
    for _ in range(100):
        patterns = ["".join(rng.choice("ab") for _ in range(rng.randint(1, 4))) for _ in range(4)]
        text = "".join(rng.choice("ab") for _ in range(40))
        matches = AhoCorasick(patterns).search(text)["matches"]
        for pattern in set(patterns):
            assert matches[pattern] == brute_force(text, pattern)


def test_aho_corasick_rejects_empty_pattern_sets() -> None:
    with pytest.raises(ValueError):
        AhoCorasick(["", ""])


# --- Trie: frequency ranking, fuzzy search, export ------------------------
def build_weighted_trie() -> Trie:
    trie = Trie()
    for word, count in (("search", 9), ("searching", 2), ("seat", 5), ("sea", 1), ("data", 4)):
        trie.insert(word, count)
    return trie


def test_top_k_orders_by_frequency_then_alphabetically() -> None:
    trie = build_weighted_trie()
    assert trie.top_k("sea", 3) == [("search", 9), ("seat", 5), ("searching", 2)]
    trie.insert("seal", 5)
    assert trie.top_k("sea", 3) == [("search", 9), ("seal", 5), ("seat", 5)]
    assert trie.top_k("zzz") == []


def test_counts_and_statistics() -> None:
    trie = build_weighted_trie()
    assert trie.word_count == 5
    assert trie.count_prefix("sea") == 4
    assert trie.frequency("search") == 9
    trie.insert("search", 1)
    assert trie.frequency("search") == 10
    assert trie.word_count == 5


def test_fuzzy_search_matches_levenshtein_definition() -> None:
    trie = build_weighted_trie()
    words = ["search", "searching", "seat", "sea", "data"]
    for query in ("serch", "seet", "dat", "sae", "xyz"):
        expected = sorted(w for w in words if levenshtein(query, w) <= 2)
        got = sorted(word for word, _, _ in trie.fuzzy_search(query, 2, 50))
        assert got == expected
    assert trie.fuzzy_search("serch", 1)[0][:2] == ("search", 1)


def test_subtree_export_keeps_prefix_path() -> None:
    trie = build_weighted_trie()
    tree = trie.subtree("sea", max_depth=2)
    node = tree
    for character in "sea":
        node = next(child for child in node["children"] if child["label"] == character)
        assert node["on_path"]
    assert node["end"] is True
    assert {child["label"] for child in node["children"]} == {"r", "t"}


# --- BM25 ------------------------------------------------------------------
def test_bm25_prefers_documents_with_rarer_and_more_frequent_terms() -> None:
    index = BM25Index()
    index.add_document(["trie", "prefix", "trie", "search"])
    index.add_document(["hash", "search", "rolling"])
    index.add_document(["search", "engine", "search"])
    ranked = index.score(["trie", "search"])
    assert ranked[0].document_id == 0
    assert index.idf("trie") > index.idf("search")
    assert {item.document_id for item in ranked} == {0, 1, 2}
    assert index.score(["missing"]) == []


def test_bm25_rejects_invalid_parameters() -> None:
    with pytest.raises(ValueError):
        BM25Index(b=2)


# --- Engine integration -----------------------------------------------------
@pytest.fixture()
def engine(tmp_path):
    (tmp_path / "a.txt").write_text("Rolling hash search uses Rabin Karp. Hash hash.", encoding="utf-8")
    (tmp_path / "b.txt").write_text("A trie supports prefix search and autocomplete.", encoding="utf-8")
    return SearchEngine(tmp_path)


def test_engine_three_way_agreement_and_bm25_order(engine) -> None:
    result = engine.search("hash")
    assert result["algorithms_agree"]
    assert result["horspool_executed"]
    top = result["results"][0]
    assert top["document"] == "a.txt"
    assert top["horspool_positions"] == top["kmp_positions"] == top["rabin_karp_positions"]
    assert top["bm25_score"] > 0


def test_engine_did_you_mean_and_ranked_search(engine) -> None:
    result = engine.search("serch")
    assert any(item["term"] == "search" for item in result["did_you_mean"])
    ranked = engine.ranked_search("prefix trie")
    assert ranked[0]["document"] == "b.txt"
    assert "search-highlight" in ranked[0]["snippet"]


def test_engine_multi_pattern_matches_kmp(engine) -> None:
    report = engine.multi_pattern_search(["hash", "search", "trie"])
    for row in report["rows"]:
        text = next(d.normalized_text for d in engine.documents if d.name == row["document"])
        assert row["positions"] == kmp_search(text, row["pattern"])["positions"]
    with pytest.raises(ValueError):
        engine.multi_pattern_search(["  "])
