"""Aho–Corasick multi-pattern matching automaton.

All patterns are compiled into a Trie whose nodes gain *failure links* (the
longest proper suffix that is also a Trie path) and *output links*. A single
left-to-right pass over the text reports every occurrence of every pattern in
O(n + Σm + z) time, where z is the number of reported matches.
"""

from __future__ import annotations

import time
from collections import deque
from collections.abc import Iterable
from typing import TypedDict


class AhoCorasickResult(TypedDict):
    """Structured output produced by :meth:`AhoCorasick.search`."""

    matches: dict[str, list[int]]
    total_matches: int
    transitions: int
    failure_steps: int
    execution_time: float


class AhoCorasick:
    """Compile patterns once, then scan any number of texts."""

    def __init__(self, patterns: Iterable[str]) -> None:
        cleaned: list[str] = []
        for pattern in patterns:
            if not isinstance(pattern, str):
                raise TypeError("Patterns must be strings")
            if pattern and pattern not in cleaned:
                cleaned.append(pattern)
        if not cleaned:
            raise ValueError("At least one non-empty pattern is required")
        self.patterns = cleaned
        self.goto: list[dict[str, int]] = [{}]
        self.fail: list[int] = [0]
        self.output: list[list[int]] = [[]]
        self._build()

    @property
    def state_count(self) -> int:
        """Number of automaton states, including the root."""
        return len(self.goto)

    def _build(self) -> None:
        for pattern_index, pattern in enumerate(self.patterns):
            state = 0
            for character in pattern:
                nxt = self.goto[state].get(character)
                if nxt is None:
                    nxt = len(self.goto)
                    self.goto[state][character] = nxt
                    self.goto.append({})
                    self.fail.append(0)
                    self.output.append([])
                state = nxt
            self.output[state].append(pattern_index)

        queue: deque[int] = deque(self.goto[0].values())
        while queue:
            state = queue.popleft()
            for character, child in self.goto[state].items():
                queue.append(child)
                fallback = self.fail[state]
                while fallback and character not in self.goto[fallback]:
                    fallback = self.fail[fallback]
                candidate = self.goto[fallback].get(character, 0)
                self.fail[child] = candidate if candidate != child else 0
                self.output[child] = self.output[child] + self.output[self.fail[child]]

    def search(self, text: str) -> AhoCorasickResult:
        """Return start positions of every pattern occurrence in ``text``."""
        if not isinstance(text, str):
            raise TypeError("Text must be a string")
        start_time = time.perf_counter()
        matches: dict[str, list[int]] = {pattern: [] for pattern in self.patterns}
        state = 0
        transitions = 0
        failure_steps = 0
        for index, character in enumerate(text):
            while state and character not in self.goto[state]:
                state = self.fail[state]
                failure_steps += 1
            state = self.goto[state].get(character, 0)
            transitions += 1
            for pattern_index in self.output[state]:
                pattern = self.patterns[pattern_index]
                matches[pattern].append(index - len(pattern) + 1)
        for positions in matches.values():
            positions.sort()
        return {
            "matches": matches,
            "total_matches": sum(len(positions) for positions in matches.values()),
            "transitions": transitions,
            "failure_steps": failure_steps,
            "execution_time": time.perf_counter() - start_time,
        }
