"""Boyer–Moore–Horspool exact pattern matching.

Horspool simplifies Boyer–Moore by keeping only the bad-character rule keyed
on the text character aligned with the *last* pattern position. Comparisons
run right-to-left inside each window, and on a mismatch the window jumps by
the precomputed shift. Preprocessing is O(m + σ); the average search is
sub-linear (≈ n / m windows for large alphabets) and the worst case is O(nm).
"""

from __future__ import annotations

import time
from typing import TypedDict


class HorspoolResult(TypedDict):
    """Structured output produced by :func:`horspool_search`."""

    positions: list[int]
    comparisons: int
    windows: int
    skipped_characters: int
    execution_time: float


def build_shift_table(pattern: str) -> dict[str, int]:
    """Return the bad-character shift for each character in ``pattern[:-1]``.

    Characters not present in the table shift by the full pattern length.
    """
    if not isinstance(pattern, str):
        raise TypeError("Pattern must be a string")
    length = len(pattern)
    return {pattern[index]: length - 1 - index for index in range(length - 1)}


def horspool_search(text: str, pattern: str) -> HorspoolResult:
    """Find every (overlapping) occurrence of ``pattern`` in ``text``."""
    if not isinstance(text, str) or not isinstance(pattern, str):
        raise TypeError("Text and pattern must be strings")

    start_time = time.perf_counter()
    positions: list[int] = []
    comparisons = 0
    windows = 0
    text_length, pattern_length = len(text), len(pattern)

    if not text or not pattern or pattern_length > text_length:
        return {
            "positions": positions,
            "comparisons": 0,
            "windows": 0,
            "skipped_characters": 0,
            "execution_time": time.perf_counter() - start_time,
        }

    shift = build_shift_table(pattern)
    last = pattern_length - 1
    window_start = 0
    while window_start <= text_length - pattern_length:
        windows += 1
        offset = last
        while offset >= 0:
            comparisons += 1
            if text[window_start + offset] != pattern[offset]:
                break
            offset -= 1
        if offset < 0:
            positions.append(window_start)
        window_start += shift.get(text[window_start + last], pattern_length)

    return {
        "positions": positions,
        "comparisons": comparisons,
        "windows": windows,
        "skipped_characters": max(0, text_length - pattern_length + 1 - windows),
        "execution_time": time.perf_counter() - start_time,
    }
