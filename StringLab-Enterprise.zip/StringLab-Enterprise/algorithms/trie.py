"""Trie data structure for prefix search, ranked autocomplete and fuzzy lookup.

The trie stores one node per character. Inserting or looking up a word takes
O(L) time, where L is the word length. Alphabetical autocomplete takes
O(P + R), where P is the prefix length and R the characters visited while
collecting suggestions. Ranked (top-k) autocomplete uses a bounded heap over
the prefix subtree. Fuzzy lookup walks the trie while maintaining one row of
the Levenshtein matrix per node, pruning any branch whose row minimum already
exceeds the distance budget, so shared prefixes are computed only once.
"""

from __future__ import annotations

import heapq
from dataclasses import dataclass, field
from typing import Any


@dataclass
class TrieNode:
    """A node containing character edges, a word-end marker and statistics."""

    children: dict[str, "TrieNode"] = field(default_factory=dict)
    is_end_of_word: bool = False
    frequency: int = 0
    prefix_count: int = 0


class Trie:
    """A case-insensitive trie supporting lookup, ranking and fuzzy search."""

    def __init__(self) -> None:
        self.root = TrieNode()
        self.node_count = 1
        self.word_count = 0

    @staticmethod
    def _normalize(value: str) -> str:
        """Return the canonical representation used by the trie."""
        if not isinstance(value, str):
            raise TypeError("Trie values must be strings")
        return value.casefold()

    def insert(self, word: str, count: int = 1) -> None:
        """Insert a word, adding ``count`` to its corpus frequency."""
        normalized_word = self._normalize(word)
        if not normalized_word:
            return
        count = max(1, int(count))

        current_node = self.root
        path = [current_node]
        for character in normalized_word:
            if character not in current_node.children:
                current_node.children[character] = TrieNode()
                self.node_count += 1
            current_node = current_node.children[character]
            path.append(current_node)
        if not current_node.is_end_of_word:
            self.word_count += 1
            for node in path:
                node.prefix_count += 1
        current_node.is_end_of_word = True
        current_node.frequency += count

    def _find(self, prefix: str) -> TrieNode | None:
        current_node = self.root
        for character in prefix:
            current_node = current_node.children.get(character)
            if current_node is None:
                return None
        return current_node

    def search(self, word: str) -> bool:
        """Return whether the complete word exists in the trie."""
        normalized_word = self._normalize(word)
        if not normalized_word:
            return False
        node = self._find(normalized_word)
        return bool(node and node.is_end_of_word)

    def frequency(self, word: str) -> int:
        """Return the stored corpus frequency of ``word`` (0 when absent)."""
        node = self._find(self._normalize(word))
        return node.frequency if node and node.is_end_of_word else 0

    def starts_with(self, prefix: str) -> bool:
        """Return whether at least one inserted word has the given prefix."""
        normalized_prefix = self._normalize(prefix)
        if not normalized_prefix:
            return bool(self.root.children)
        return self._find(normalized_prefix) is not None

    def count_prefix(self, prefix: str) -> int:
        """Return how many distinct words share ``prefix``."""
        node = self._find(self._normalize(prefix))
        return node.prefix_count if node else 0

    def autocomplete(self, prefix: str, limit: int = 10) -> list[str]:
        """Return up to ``limit`` unique words beginning with ``prefix``."""
        if limit <= 0:
            return []

        normalized_prefix = self._normalize(prefix)
        current_node = self._find(normalized_prefix)
        if current_node is None:
            return []

        suggestions: list[str] = []

        def collect(node: TrieNode, current_word: str) -> None:
            if len(suggestions) >= limit:
                return
            if node.is_end_of_word:
                suggestions.append(current_word)
            for character in sorted(node.children):
                collect(node.children[character], current_word + character)

        collect(current_node, normalized_prefix)
        return suggestions

    def top_k(self, prefix: str, k: int = 10) -> list[tuple[str, int]]:
        """Return the ``k`` most frequent words under ``prefix``.

        Ties are broken alphabetically. Runs in O(S log k) for a subtree of
        S nodes using a bounded min-heap.
        """
        if k <= 0:
            return []
        normalized_prefix = self._normalize(prefix)
        start = self._find(normalized_prefix)
        if start is None:
            return []
        heap: list[tuple[int, str]] = []
        stack: list[tuple[TrieNode, str]] = [(start, normalized_prefix)]
        while stack:
            node, word = stack.pop()
            if node.is_end_of_word and word:
                # Negated word keeps alphabetical order among equal counts.
                entry = (node.frequency, _ReverseStr(word))
                if len(heap) < k:
                    heapq.heappush(heap, entry)  # type: ignore[arg-type]
                elif entry > heap[0]:
                    heapq.heapreplace(heap, entry)  # type: ignore[arg-type]
            for character, child in node.children.items():
                stack.append((child, word + character))
        ranked = sorted(heap, reverse=True)
        return [(str(word), count) for count, word in ranked]

    def fuzzy_search(
        self,
        word: str,
        max_distance: int = 2,
        limit: int = 10,
    ) -> list[tuple[str, int, int]]:
        """Return ``(word, edit_distance, frequency)`` within the budget.

        Results are ordered by distance, then by descending frequency.
        """
        target = self._normalize(word)
        if not target or max_distance < 0 or limit <= 0:
            return []
        first_row = list(range(len(target) + 1))
        results: list[tuple[str, int, int]] = []

        def walk(node: TrieNode, character: str, prefix: str, previous: list[int]) -> None:
            columns = len(target) + 1
            current = [previous[0] + 1]
            for column in range(1, columns):
                insert_cost = current[column - 1] + 1
                delete_cost = previous[column] + 1
                replace_cost = previous[column - 1] + (target[column - 1] != character)
                current.append(min(insert_cost, delete_cost, replace_cost))
            if node.is_end_of_word and current[-1] <= max_distance:
                results.append((prefix, current[-1], node.frequency))
            if min(current) <= max_distance:
                for next_character, child in node.children.items():
                    walk(child, next_character, prefix + next_character, current)

        for character, child in self.root.children.items():
            walk(child, character, character, first_row)
        results.sort(key=lambda item: (item[1], -item[2], item[0]))
        return results[:limit]

    def subtree(
        self,
        prefix: str = "",
        max_depth: int = 4,
        max_children: int = 6,
    ) -> dict[str, Any]:
        """Export a bounded, JSON-friendly view of the trie for diagrams.

        The returned tree starts at the root and always includes the full
        ``prefix`` path, then expands ``max_depth`` levels below it. Branches
        beyond ``max_children`` per node are summarised as a ``hidden`` count.
        """
        normalized_prefix = self._normalize(prefix)

        def export(node: TrieNode, label: str, word: str, depth: int, on_path: bool) -> dict[str, Any]:
            item: dict[str, Any] = {
                "label": label,
                "word": word,
                "end": node.is_end_of_word,
                "frequency": node.frequency,
                "prefix_count": node.prefix_count,
                "on_path": on_path,
                "children": [],
                "hidden": 0,
            }
            path_index = len(word)
            if on_path and path_index < len(normalized_prefix):
                next_character = normalized_prefix[path_index]
                child = node.children.get(next_character)
                if child is not None:
                    item["children"].append(
                        export(child, next_character, word + next_character, 0, True)
                    )
                item["hidden"] = len(node.children) - (1 if child is not None else 0)
                return item
            if depth >= max_depth:
                item["hidden"] = len(node.children)
                return item
            ordered = sorted(
                node.children.items(),
                key=lambda pair: (-pair[1].prefix_count, pair[0]),
            )
            for character, child in ordered[:max_children]:
                item["children"].append(
                    export(child, character, word + character, depth + 1, False)
                )
            item["children"].sort(key=lambda child_item: child_item["label"])
            item["hidden"] = max(0, len(ordered) - max_children)
            return item

        return export(self.root, "∅", "", 0, True)


class _ReverseStr(str):
    """String whose ordering is reversed, for alphabetical tie-breaks in heaps."""

    def __lt__(self, other: str) -> bool:  # type: ignore[override]
        return str.__gt__(self, other)

    def __gt__(self, other: str) -> bool:  # type: ignore[override]
        return str.__lt__(self, other)

    def __le__(self, other: str) -> bool:  # type: ignore[override]
        return str.__ge__(self, other)

    def __ge__(self, other: str) -> bool:  # type: ignore[override]
        return str.__le__(self, other)
