# StringLab architecture

The Mermaid diagrams below render on GitHub, GitLab, VS Code (Markdown Preview Mermaid) and most Markdown viewers.
The pixel-exact SVG versions, the same ones the app draws, are in [`docs/diagrams/`](diagrams/).

![System architecture](diagrams/architecture.svg)

## 1. System architecture

```mermaid
flowchart LR
    subgraph BUILD["Build time — once per document"]
        direction LR
        ING["Ingestion<br/>TXT · PDF · DOCX<br/>10 MiB / 500-page guard<br/>SHA-256 de-dup"] --> TP["Text processing<br/>casefold · Unicode tokens<br/>term frequencies"]
        TP --> TRIE["Trie<br/>frequency-weighted nodes"]
        TP --> BLOOM["Bloom filter<br/>k hashes · m bits"]
        TP --> BM25["BM25 inverted index<br/>term → {doc: tf}"]
        ING -. raw text .-> DB[("SQLite<br/>documents · search_history")]
    end

    subgraph QUERY["Query time — every search"]
        direction LR
        Q["Query<br/>normalise · tokenise"] --> BS{"Bloom screen"}
        BS -- "definitely absent" --> DYM["Did-you-mean<br/>fuzzy Trie (Levenshtein)"]
        BS -- "possibly present" --> RANK["BM25 rank"]
        RANK --> VER["Exact verification<br/>KMP · Rabin–Karp · Horspool"]
        VER --> EV["Evidence<br/>highlights · positions<br/>3-way agreement · metrics"]
    end

    BLOOM -.-> BS
    TRIE -.-> DYM
    BM25 -.-> RANK
    EV -. "query metadata" .-> DB

    subgraph TOOLS["Tools on the same indexes"]
        TX["Trie explorer<br/>top-k · fuzzy"]
        AC["Multi-pattern scan<br/>Aho–Corasick"]
        BL["Benchmark lab<br/>median timings · CSV"]
    end
    TRIE -.-> TX
```

## 2. Search request sequence

```mermaid
sequenceDiagram
    actor U as User
    participant UI as Streamlit UI (app.py)
    participant SE as SearchEngine
    participant BF as BloomFilter
    participant T as Trie
    participant R as BM25Index
    participant M as KMP / Rabin–Karp / Horspool
    participant DB as SQLite

    U->>UI: phrase "rolling hash"
    UI->>SE: search(query)
    SE->>SE: casefold + tokenise
    alt single word, not in Bloom and not a Trie prefix
        SE->>BF: might_contain(word) → false
        SE->>T: fuzzy_search(word, ≤2 edits)
        SE->>DB: log_search(0 matches)
        SE-->>UI: did_you_mean[]
    else candidate
        SE->>R: score(query_terms)
        loop every document
            SE->>M: kmp_search, rabin_karp_search, horspool_search
            M-->>SE: positions + operation counts
            SE->>SE: assert KMP == RK == Horspool
        end
        SE->>SE: order results by BM25 score
        SE->>DB: log_search(matches, elapsed)
        SE-->>UI: results, contexts, metrics
    end
    UI-->>U: highlighted occurrences + agreement verdict
```

## 3. Module map

```mermaid
classDiagram
    direction LR
    class SearchEngine {
        +documents
        +trie: Trie
        +bloom_filter: BloomFilter
        +bm25: BM25Index
        +search(query) dict
        +ranked_search(query, limit) list
        +ranked_terms(prefix, limit) list
        +fuzzy(word, max_distance) list
        +multi_pattern_search(patterns) dict
        +add_document(name, text) bool
    }
    class Trie {
        +insert(word, count)
        +search(word) bool
        +starts_with(prefix) bool
        +autocomplete(prefix, limit) list
        +top_k(prefix, k) list
        +fuzzy_search(word, d, limit) list
        +subtree(prefix, depth, breadth) dict
    }
    class BM25Index {
        +k1 = 1.5
        +b = 0.75
        +add_document(tokens) int
        +idf(term) float
        +score(terms, limit) list
    }
    class AhoCorasick {
        +goto / fail / output
        +search(text) dict
    }
    class BloomFilter {
        +add(item)
        +might_contain(item) bool
    }
    class DocumentManager
    class Storage
    SearchEngine --> Trie
    SearchEngine --> BloomFilter
    SearchEngine --> BM25Index
    SearchEngine --> AhoCorasick : builds per scan
    SearchEngine --> DocumentManager
    SearchEngine --> Storage
    SearchEngine ..> kmp_search
    SearchEngine ..> rabin_karp_search
    SearchEngine ..> horspool_search
```

## 4. Trie

Each edge is one character; a double ring marks the end of a whole word. Nodes keep `prefix_count`
(how many words lie below) and `frequency` (corpus occurrences), so the Trie can rank completions.

![Trie for prefix "se"](diagrams/trie_prefix_se.svg)

```mermaid
graph TD
    R((root)) --> S((s))
    S --> E((e))
    E --> A((a))
    A --> AR((r))
    AR --> ARC((c))
    ARC --> ARCH(((h)))
    A --> AT(((t)))
    E --> T2((t))
    style S fill:#F5D547,stroke:#15233F
    style E fill:#F5D547,stroke:#15233F
    style R fill:#15233F,color:#fff
```

*Fuzzy lookup* walks this tree while computing one Levenshtein row per node and prunes any branch whose
smallest cell already exceeds the edit budget, so a shared prefix is computed once for every word below it.

## 5. Aho–Corasick automaton (`he`, `she`, `his`, `hers`)

Solid arrows are goto transitions; dashed arrows are failure links; yellow states emit matches.

![Aho–Corasick automaton](diagrams/aho_corasick_automaton.svg)

```mermaid
stateDiagram-v2
    direction LR
    [*] --> 0
    0 --> 1: h
    1 --> 2: e
    2 --> 8: r
    8 --> 9: s
    1 --> 6: i
    6 --> 7: s
    0 --> 3: s
    3 --> 4: h
    4 --> 5: e
    4 --> 1: fail
    5 --> 2: fail
    7 --> 3: fail
    9 --> 3: fail
    note right of 5: emits she + he
    note right of 9: emits hers
```

## 6. Pre-computed tables

| KMP prefix function | Horspool bad-character shifts |
| --- | --- |
| ![LPS](diagrams/kmp_lps_abracadabra.svg) | ![Shift](diagrams/horspool_shift_abracadabra.svg) |

## 7. Complexity

| Technique | Time | Space |
| --- | --- | --- |
| Trie lookup / autocomplete | `O(m)` + output | `O(total chars)` |
| Trie top-k | `O(S log k)` for subtree S | `O(k)` |
| Fuzzy Trie | `O(visited nodes · m)`, pruned | `O(m · depth)` |
| KMP | `O(n + m)` | `O(m)` |
| Rabin–Karp | avg `O(n + m)`, worst `O(nm)` | `O(1)` |
| Boyer–Moore–Horspool | avg sub-linear, worst `O(nm)` | `O(σ)` |
| Aho–Corasick | `O(n + Σm + z)` | `O(Σm · σ)` |
| BM25 scoring | `O(postings of query terms)` | `O(postings)` |
| Bloom filter | `O(k)` | `O(bits)` |
