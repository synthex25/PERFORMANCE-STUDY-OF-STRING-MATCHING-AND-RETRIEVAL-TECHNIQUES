"""Okapi BM25 relevance ranking over an inverted index.

The index maps each term to a postings dictionary ``{document_id: tf}``.
Scoring a query touches only the postings of its terms, so ranking cost is
proportional to the matching postings rather than the corpus size.

    score(D, Q) = Σ IDF(q) · tf·(k1 + 1) / (tf + k1·(1 − b + b·|D|/avgdl))
    IDF(q)      = ln(1 + (N − df + 0.5) / (df + 0.5))
"""

from __future__ import annotations

import math
from collections import Counter
from collections.abc import Sequence
from dataclasses import dataclass


@dataclass(frozen=True)
class RankedDocument:
    """One scored document with an explanation of its contributing terms."""

    document_id: int
    score: float
    term_contributions: dict[str, float]
    matched_terms: tuple[str, ...]


class BM25Index:
    """Incremental inverted index with BM25 scoring."""

    def __init__(self, k1: float = 1.5, b: float = 0.75) -> None:
        if k1 < 0 or not 0 <= b <= 1:
            raise ValueError("BM25 requires k1 >= 0 and 0 <= b <= 1")
        self.k1 = k1
        self.b = b
        self.postings: dict[str, dict[int, int]] = {}
        self.document_lengths: list[int] = []

    @property
    def document_count(self) -> int:
        return len(self.document_lengths)

    @property
    def average_length(self) -> float:
        if not self.document_lengths:
            return 0.0
        return sum(self.document_lengths) / len(self.document_lengths)

    @property
    def vocabulary_size(self) -> int:
        return len(self.postings)

    @property
    def posting_count(self) -> int:
        return sum(len(postings) for postings in self.postings.values())

    def add_document(self, tokens: Sequence[str]) -> int:
        """Index a tokenised document and return its integer identifier."""
        document_id = len(self.document_lengths)
        self.document_lengths.append(len(tokens))
        for term, frequency in Counter(tokens).items():
            self.postings.setdefault(term, {})[document_id] = frequency
        return document_id

    def document_frequency(self, term: str) -> int:
        return len(self.postings.get(term, {}))

    def idf(self, term: str) -> float:
        df = self.document_frequency(term)
        n = self.document_count
        return math.log(1 + (n - df + 0.5) / (df + 0.5))

    def score(self, query_terms: Sequence[str], limit: int = 10) -> list[RankedDocument]:
        """Return up to ``limit`` documents ordered by descending BM25 score."""
        if not query_terms or not self.document_lengths:
            return []
        average_length = self.average_length or 1.0
        contributions: dict[int, dict[str, float]] = {}
        for term in dict.fromkeys(query_terms):
            postings = self.postings.get(term)
            if not postings:
                continue
            idf = self.idf(term)
            for document_id, tf in postings.items():
                length_norm = 1 - self.b + self.b * self.document_lengths[document_id] / average_length
                weight = idf * tf * (self.k1 + 1) / (tf + self.k1 * length_norm)
                contributions.setdefault(document_id, {})[term] = weight
        ranked = [
            RankedDocument(
                document_id=document_id,
                score=sum(terms.values()),
                term_contributions=terms,
                matched_terms=tuple(terms),
            )
            for document_id, terms in contributions.items()
        ]
        ranked.sort(key=lambda item: (-item.score, item.document_id))
        return ranked[: max(0, limit)]
