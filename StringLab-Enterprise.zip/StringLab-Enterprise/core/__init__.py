"""Application coordination and domain services."""
