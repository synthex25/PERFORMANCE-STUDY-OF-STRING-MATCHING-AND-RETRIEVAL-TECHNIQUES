"""StringLab — string matching & retrieval studio (Streamlit interface)."""

from __future__ import annotations

import platform
from datetime import datetime
from html import escape
from pathlib import Path

import altair as alt
import pandas as pd
import streamlit as st

from algorithms.aho_corasick import AhoCorasick
from algorithms.boyer_moore import build_shift_table, horspool_search
from algorithms.kmp import build_lps, kmp_search
from algorithms.rabin_karp import rabin_karp_search
from core.benchmark import (
    benchmark_bloom_filter,
    benchmark_pattern_sizes,
    benchmark_text_sizes,
)
from core.ingestion import extract_text
from core.search_engine import SearchEngine
from core.storage import Storage
from ui import diagrams
from ui.theme import ALGO_COLORS, CSS, PALETTE

def _altair_theme() -> dict:
    font = "Public Sans, Segoe UI, system-ui, sans-serif"
    return {"config": {"font": font, "axis": {"labelFont": font, "titleFont": font},
                       "legend": {"labelFont": font, "titleFont": font}, "background": "transparent"}}


try:  # Altair >= 5.5
    alt.theme.register("stringlab", enable=True)(_altair_theme)
except AttributeError:  # older Altair 5.x
    alt.themes.register("stringlab", _altair_theme)
    alt.themes.enable("stringlab")

PROJECT_ROOT = Path(__file__).resolve().parent
DOCUMENTS_DIRECTORY = PROJECT_ROOT / "data" / "sample_documents"
DATABASE_PATH = PROJECT_ROOT / "data" / "stringlab.sqlite3"

PAGES = (
    "Overview",
    "Search",
    "Trie explorer",
    "Multi-pattern scan",
    "Algorithm internals",
    "Bloom filter",
    "Benchmark lab",
    "Documents",
    "Search history",
    "How it works",
)


# --------------------------------------------------------------------------- #
# helpers
# --------------------------------------------------------------------------- #
def format_probability(probability: float) -> str:
    """Format a probability without hiding a small non-zero value."""
    if probability == 0:
        return "0%"
    percent = probability * 100
    return f"{percent:.2g}%" if percent < 0.1 else f"{percent:.2f}%"


def format_runtime(seconds: float) -> str:
    """Format short algorithm timings in readable engineering units."""
    if seconds < 0.001:
        return f"{seconds * 1_000_000:.1f} µs"
    if seconds < 1:
        return f"{seconds * 1_000:.2f} ms"
    return f"{seconds:.3f} s"


def html(markup: str) -> None:
    st.markdown(markup, unsafe_allow_html=True)


def header(title: str, subtitle: str) -> None:
    html(f'<div class="sl-head"><h1>{title}</h1><p>{subtitle}</p></div>')


def section(title: str, subtitle: str = "") -> None:
    html(f'<div class="sl-h2">{title}</div>' + (f'<p class="sl-sub">{subtitle}</p>' if subtitle else ""))


def stats_row(items: list[tuple[str, str]]) -> None:
    cells = "".join(f'<div class="sl-stat"><b>{value}</b><span>{label}</span></div>' for label, value in items)
    html(f'<div class="sl-stats">{cells}</div>')


def verdict(ok: bool, good: str, bad: str) -> str:
    return f'<span class="sl-verdict {"ok" if ok else "bad"}">{"✓" if ok else "✕"} {good if ok else bad}</span>'


def go_to(page: str) -> None:
    st.session_state["nav"] = page


def algo_chart(frame: pd.DataFrame, x: str, x_title: str, y_title: str = "Median runtime (s, log scale)", log: bool = True) -> alt.Chart:
    domain = list(ALGO_COLORS)
    base = alt.Chart(frame).encode(
        x=alt.X(f"{x}:Q", title=x_title, scale=alt.Scale(type="log" if x == "text_size" else "linear")),
        y=alt.Y("value:Q", title=y_title, scale=alt.Scale(type="log" if log else "linear")),
        color=alt.Color("algorithm:N", scale=alt.Scale(domain=domain, range=[ALGO_COLORS[a] for a in domain]),
                        legend=alt.Legend(orient="top", title=None)),
        tooltip=[alt.Tooltip(f"{x}:Q", format=","), "algorithm:N", alt.Tooltip("value:Q", format=".3~g")],
    )
    return (base.mark_line(strokeWidth=2.4) + base.mark_point(filled=True, size=55)).properties(height=300).configure_view(
        strokeWidth=0
    ).configure_axis(
        labelColor=PALETTE["ink_soft"], titleColor=PALETTE["ink"], gridColor="#E3E9F2", domainColor=PALETTE["line"],
    ).configure_legend(labelColor=PALETTE["ink"])


@st.cache_resource
def load_engine() -> SearchEngine:
    """Build the document indexes once per Streamlit process."""
    return SearchEngine(DOCUMENTS_DIRECTORY, storage_path=DATABASE_PATH)


# --------------------------------------------------------------------------- #
# Overview
# --------------------------------------------------------------------------- #
def render_overview(engine: SearchEngine) -> None:
    query = "search"
    best = None
    for document in engine.documents:
        positions = kmp_search(document.normalized_text, query)["positions"]
        if positions and (best is None or len(positions) > len(best[1])):
            best = (document, positions)

    specimen = ""
    if best:
        document, positions = best
        text = document.normalized_text
        runs = {
            "KMP": kmp_search(text, query)["comparisons"],
            "Rabin–Karp": rabin_karp_search(text, query)["character_verifications"] + rabin_karp_search(text, query)["hash_comparisons"],
            "Horspool": horspool_search(text, query)["comparisons"],
        }
        longest = max(runs.values()) or 1
        lanes = "".join(
            f'<div class="sl-lane"><span class="sl-lane-name" style="color:{ALGO_COLORS[name]}">{name}</span>'
            f'<span class="sl-lane-bar"><i style="width:{value / longest * 100:.1f}%;background:{ALGO_COLORS[name]};animation-delay:{i * 140}ms"></i></span>'
            f'<span class="sl-lane-num">{value:,} ops</span></div>'
            for i, (name, value) in enumerate(runs.items())
        )
        specimen = (
            f'<div class="sl-specimen"><div class="sl-specimen-q">Searching for <b>{query}</b> in {escape(document.name)} — '
            f'{len(positions)} hits</div>'
            f'{diagrams.highlight_strip(document.original_text, positions, len(query), 330)}'
            f'<div class="sl-lanes">{lanes}</div>'
            f'<p class="sl-muted" style="margin:.7rem 0 0">Same positions from all three; different amounts of work.</p></div>'
        )

    html(
        '<div class="sl-hero"><div>'
        "<h1>Watch three algorithms find the same word.</h1>"
        '<p class="lede">StringLab indexes your documents, ranks them with BM25 and verifies every hit with KMP, '
        "Rabin–Karp and Boyer–Moore–Horspool, so you can see where each one does less work.</p></div>"
        f"<div>{specimen}</div></div>"
    )
    cols = st.columns([1, 1, 1, 3])
    cols[0].button("Search the corpus", on_click=go_to, args=("Search",), type="primary", use_container_width=True)
    cols[1].button("Explore the Trie", on_click=go_to, args=("Trie explorer",), type="secondary", use_container_width=True)
    cols[2].button("Run benchmarks", on_click=go_to, args=("Benchmark lab",), type="secondary", use_container_width=True)

    total_chars = sum(len(d.original_text) for d in engine.documents)
    stats_row([
        ("documents indexed", f"{engine.document_count}"),
        ("characters", f"{total_chars:,}"),
        ("distinct terms", f"{engine.indexed_term_count:,}"),
        ("Trie nodes", f"{engine.trie.node_count:,}"),
        ("BM25 postings", f"{engine.bm25.posting_count:,}"),
        ("Bloom false-positive rate", format_probability(engine.bloom_filter.calculate_false_positive_rate())),
    ])

    section("How a query moves through the system",
            "Documents are indexed once into three structures. Each search is screened, ranked, then verified exactly.")
    html(diagrams.architecture_svg())


# --------------------------------------------------------------------------- #
# Search
# --------------------------------------------------------------------------- #
def _use_suggestion(term: str) -> None:
    st.session_state["search_query"] = term
    st.session_state["run_search"] = True


def render_search(engine: SearchEngine) -> None:
    header("Search", "Exact phrase search verified by three algorithms, ordered by BM25 relevance. "
                     "Switch to relevance mode to rank documents by any of your words.")
    exact_tab, ranked_tab = st.tabs(["Exact phrase", "Relevance (any words)"])

    with exact_tab:
        with st.form("search_form", border=False):
            cols = st.columns([5, 1])
            query = cols[0].text_input("Phrase", placeholder="rolling hash, trie, prefix function…",
                                       key="search_query", label_visibility="collapsed")
            submitted = cols[1].form_submit_button("Search", use_container_width=True)
        if submitted or st.session_state.pop("run_search", False):
            if query.strip():
                st.session_state["last_search"] = engine.search(query)
            else:
                st.warning("Type a word or phrase to search.")
        result = st.session_state.get("last_search")
        if result:
            _render_exact_results(result)

    with ranked_tab:
        with st.form("ranked_form", border=False):
            cols = st.columns([5, 1])
            ranked_query = cols[0].text_input("Words", placeholder="fuzzy edit distance trie",
                                              key="ranked_query", label_visibility="collapsed")
            ranked_go = cols[1].form_submit_button("Rank", use_container_width=True)
        if ranked_go and ranked_query.strip():
            st.session_state["last_ranked"] = (ranked_query, engine.ranked_search(ranked_query))
        if st.session_state.get("last_ranked"):
            q, ranked = st.session_state["last_ranked"]
            if not ranked:
                st.info(f"None of the words in “{q}” appear in the corpus.")
            top = ranked[0]["score"] if ranked else 1
            for rank, item in enumerate(ranked, 1):
                contributions = " ".join(
                    f'<span class="sl-chip">{escape(t)} <small>+{w:.2f}</small></span>'
                    for t, w in sorted(item["term_contributions"].items(), key=lambda kv: -kv[1])
                )
                html(
                    f'<div class="sl-result"><div class="sl-result-top"><span class="sl-result-name">{rank}. {escape(item["document"])}</span>'
                    f'<span class="sl-score">BM25 {item["score"]:.3f} · {item["coverage"]:.0%} of words</span></div>'
                    f'<div class="sl-scorebar"><i style="width:{item["score"] / top * 100:.0f}%"></i></div>'
                    f'<div>{contributions}</div><div class="sl-context">{item["snippet"]}</div></div>'
                )


def _render_exact_results(result: dict) -> None:
    query = result["query"]
    meta = [verdict(result["algorithms_agree"], "KMP, Rabin–Karp and Horspool agree", "Algorithms disagree")]
    if result["bloom_filter"]["status"] == "Definitely Not Present":
        meta = ['<span class="sl-verdict neutral">Bloom filter: term is definitely absent — exact search skipped</span>']
    html(f'<div style="display:flex;gap:.6rem;flex-wrap:wrap;margin:.4rem 0 1rem">{"".join(meta)}</div>')
    if result.get("validation_error"):
        st.error(result["validation_error"])

    if result["did_you_mean"]:
        html('<p class="sl-muted" style="margin-bottom:.3rem">No exact matches. Did you mean:</p>')
        cols = st.columns(min(5, len(result["did_you_mean"])))
        for col, item in zip(cols, result["did_you_mean"]):
            col.button(f'{item["term"]}', key=f'dym-{item["term"]}', on_click=_use_suggestion, args=(item["term"],),
                       type="secondary", help=f'{item["distance"]} edit(s) away · appears {item["frequency"]}×',
                       use_container_width=True)
        return
    if not result["results"]:
        st.info(f"“{query}” does not occur in any indexed document. Try a shorter phrase.")
        return

    stats_row([
        ("occurrences", f'{result.get("match_count", 0):,}'),
        ("documents matched", f'{len(result["results"])}'),
        ("end-to-end time", format_runtime(result.get("execution_time", 0))),
    ])
    top = max(item["bm25_score"] for item in result["results"]) or 1
    for item in result["results"]:
        contexts = item["highlighted_contexts"]
        shown = "".join(f'<div class="sl-context">{c}</div>' for c in contexts[:3])
        algos = (
            f'<span><i class="sl-dot" style="background:{ALGO_COLORS["KMP"]}"></i>KMP <b>{item["kmp_comparisons"]:,}</b> comparisons · {format_runtime(item["kmp_time"])}</span>'
            f'<span><i class="sl-dot" style="background:{ALGO_COLORS["Rabin–Karp"]}"></i>Rabin–Karp <b>{item["hash_comparisons"]:,}</b> hashes + <b>{item["character_verifications"]:,}</b> checks · {format_runtime(item["rabin_karp_time"])}</span>'
            f'<span><i class="sl-dot" style="background:{ALGO_COLORS["Horspool"]}"></i>Horspool <b>{item["horspool_comparisons"]:,}</b> comparisons in {item["horspool_windows"]:,} windows · {format_runtime(item["horspool_time"])}</span>'
        )
        html(
            f'<div class="sl-result"><div class="sl-result-top"><span class="sl-result-name">{escape(item["document"])}</span>'
            f'<span class="sl-score">{len(item["kmp_positions"])} hit(s) · BM25 {item["bm25_score"]:.3f}</span></div>'
            f'<div class="sl-scorebar"><i style="width:{item["bm25_score"] / top * 100:.0f}%"></i></div>'
            f'{shown}<div class="sl-algos">{algos}</div></div>'
        )
        if len(contexts) > 3:
            with st.expander(f"{len(contexts) - 3} more occurrence(s) in {item['document']}"):
                html("".join(f'<div class="sl-context">{c}</div>' for c in contexts[3:]))


# --------------------------------------------------------------------------- #
# Trie explorer
# --------------------------------------------------------------------------- #
def render_trie(engine: SearchEngine) -> None:
    header("Trie explorer", "Type a prefix to see the path it takes through the Trie, the words below it ranked by how often "
                            "they appear, and close spellings found by edit distance.")
    cols = st.columns([3, 1.2, 1.2])
    prefix = cols[0].text_input("Prefix", value=st.session_state.get("trie_prefix", "se"), key="trie_prefix",
                                placeholder="al, data, se…")
    depth = cols[1].slider("Levels below prefix", 1, 6, 3)
    breadth = cols[2].slider("Branches per node", 2, 10, 5)
    normalized = prefix.strip().casefold()

    if normalized and not engine.trie.starts_with(normalized):
        st.markdown(f'<span class="sl-verdict bad">✕ No indexed word starts with “{escape(normalized)}”</span>',
                    unsafe_allow_html=True)
        close = engine.fuzzy(normalized, limit=8)
        if close:
            html('<p class="sl-muted" style="margin:.8rem 0 .3rem">Closest indexed words:</p>' + "".join(
                f'<span class="sl-chip">{escape(i["term"])} <small>{i["distance"]} edit(s)</small></span>' for i in close))
        tree = engine.trie.subtree("", max_depth=2, max_children=breadth)
        section("Top of the Trie")
        html(diagrams.trie_svg(tree, ""))
        html(diagrams.trie_legend())
        return

    words_below = engine.trie.count_prefix(normalized) if normalized else engine.trie.word_count
    stats_row([
        ("words share this prefix", f"{words_below:,}"),
        ("characters traversed", f"{len(normalized)}"),
        ("Trie nodes in total", f"{engine.trie.node_count:,}"),
        ("whole word?", "yes" if engine.trie.search(normalized) else "no"),
    ])
    tree = engine.trie.subtree(normalized, max_depth=depth, max_children=breadth)
    html(diagrams.trie_svg(tree, normalized))
    html(diagrams.trie_legend())

    left, right = st.columns([1.1, 1])
    with left:
        section("Most frequent completions", "Ranked by corpus frequency using a bounded heap over the prefix subtree.")
        ranked = engine.ranked_terms(normalized, 12)
        if ranked:
            frame = pd.DataFrame(ranked, columns=["term", "frequency"])
            chart = alt.Chart(frame).mark_bar(color=PALETTE["ink"], cornerRadiusEnd=3, height=16).encode(
                x=alt.X("frequency:Q", title="occurrences in corpus"),
                y=alt.Y("term:N", sort="-x", title=None, axis=alt.Axis(labelFont="IBM Plex Mono, Menlo, Consolas, monospace", labelFontSize=12)),
                tooltip=["term", "frequency"],
            ).properties(height=max(120, 26 * len(frame))).configure_view(strokeWidth=0).configure_axis(
                labelColor=PALETTE["ink"], titleColor=PALETTE["ink_soft"], gridColor="#E3E9F2")
            st.altair_chart(chart, use_container_width=True)
    with right:
        section("Alphabetical order", "Depth-first walk of the subtree — the classic autocomplete order.")
        html("".join(f'<span class="sl-chip">{escape(w)}</span>' for w in engine.autocomplete(normalized, 18)))
        if len(normalized) >= 3:
            section("Close spellings", "Levenshtein distance computed row by row while walking the Trie.")
            close = engine.fuzzy(normalized, limit=8)
            html("".join(f'<span class="sl-chip">{escape(i["term"])} <small>{i["distance"]} edit(s)</small></span>'
                         for i in close) or '<p class="sl-muted">No words within two edits.</p>')


# --------------------------------------------------------------------------- #
# Multi-pattern scan
# --------------------------------------------------------------------------- #
def render_multi_pattern(engine: SearchEngine) -> None:
    header("Multi-pattern scan", "Compile several patterns into one Aho–Corasick automaton and find all of them in a single "
                                 "pass over each document, instead of one scan per pattern.")
    raw = st.text_area("Patterns, one per line or separated by commas", value="hash\nhas\nsearch\narch\ntrie", height=130)
    patterns = [p.strip() for chunk in raw.splitlines() for p in chunk.split(",") if p.strip()]
    if not st.button("Scan corpus", type="primary"):
        if "last_multi" not in st.session_state:
            return
    else:
        try:
            st.session_state["last_multi"] = engine.multi_pattern_search(patterns)
        except ValueError as error:
            st.error(str(error))
            return
    report = st.session_state["last_multi"]
    stats_row([
        ("patterns", f'{len(report["patterns"])}'),
        ("automaton states", f'{report["states"]}'),
        ("total matches", f'{report["total_matches"]:,}'),
        ("one Aho–Corasick pass", format_runtime(report["automaton_time"])),
        ("one KMP scan per pattern", format_runtime(report["repeated_kmp_time"])),
    ])
    section("The automaton", "Solid edges are Trie transitions. Dashed arrows are failure links: where to resume after a "
                             "mismatch. Highlighted states emit a match.")
    html(diagrams.aho_corasick_svg(AhoCorasick(report["patterns"])))
    section("Matches by document")
    frame = pd.DataFrame(report["rows"])
    pivot = frame.pivot_table(index="document", columns="pattern", values="count", aggfunc="sum").fillna(0).astype(int)
    st.dataframe(pivot, use_container_width=True)


# --------------------------------------------------------------------------- #
# Algorithm internals
# --------------------------------------------------------------------------- #
def render_internals(engine: SearchEngine) -> None:
    header("Algorithm internals", "See the tables each algorithm builds from your pattern, then how much work each does "
                                  "scanning the whole corpus for it.")
    default = (st.session_state.get("last_search") or {}).get("query") or "abracadabra"
    pattern = st.text_input("Pattern", value=default, key="internals_pattern").casefold()
    if not pattern:
        return
    left, right = st.columns(2)
    with left:
        section("KMP · prefix function", "Each value is the length of the longest proper prefix that is also a suffix "
                                         "ending there — how far KMP can fall back without moving the text pointer.")
        html(diagrams.lps_svg(pattern, build_lps(pattern)))
    with right:
        section("Horspool · bad-character shifts", "How far the window jumps when the character under the pattern's last "
                                                  "position is this one. Anything else jumps the full length.")
        html(diagrams.shift_table_svg(pattern, build_shift_table(pattern)))

    corpus = "\n".join(d.normalized_text for d in engine.documents)
    k, r, h = kmp_search(corpus, pattern), rabin_karp_search(corpus, pattern), horspool_search(corpus, pattern)
    section("Work done on the full corpus", f"{len(corpus):,} characters scanned for “{escape(pattern)}”.")
    html(verdict(k["positions"] == r["positions"] == h["positions"],
                 f'All three report the same {len(k["positions"])} position(s)', "Positions differ"))
    frame = pd.DataFrame([
        {"algorithm": "KMP", "operation": "character comparisons", "count": k["comparisons"]},
        {"algorithm": "Rabin–Karp", "operation": "hash comparisons", "count": r["hash_comparisons"]},
        {"algorithm": "Rabin–Karp", "operation": "character verifications", "count": r["character_verifications"]},
        {"algorithm": "Horspool", "operation": "character comparisons", "count": h["comparisons"]},
        {"algorithm": "Horspool", "operation": "windows examined", "count": h["windows"]},
    ])
    frame["label"] = frame["algorithm"] + " — " + frame["operation"]
    chart = alt.Chart(frame).mark_bar(cornerRadiusEnd=3, height=20).encode(
        y=alt.Y("label:N", title=None, sort=list(frame["label"]), axis=alt.Axis(labelLimit=320, labelFontSize=12)),
        x=alt.X("count:Q", title="operations"),
        color=alt.Color("algorithm:N", scale=alt.Scale(domain=list(ALGO_COLORS), range=list(ALGO_COLORS.values())),
                        legend=None),
        tooltip=["algorithm", "operation", alt.Tooltip("count:Q", format=",")],
    ).properties(height=34 * len(frame)).configure_view(strokeWidth=0).configure_axis(
        gridColor="#E3E9F2", labelColor=PALETTE["ink"], titleColor=PALETTE["ink_soft"])
    st.altair_chart(chart, use_container_width=True)
    html(f'<p class="sl-muted">Horspool skipped {h["skipped_characters"]:,} alignment(s) entirely; KMP never re-reads a '
         "text character; Rabin–Karp touches every window once but only compares characters when hashes collide.</p>")


# --------------------------------------------------------------------------- #
# Bloom filter
# --------------------------------------------------------------------------- #
def render_bloom(engine: SearchEngine) -> None:
    bloom = engine.bloom_filter
    header("Bloom filter", "A compact bit array that can say a word is definitely absent before any text is scanned. "
                           "A yes only means possibly present, so every yes is verified exactly.")
    term = st.text_input("Word to test", value="trie", key="bloom_term").strip().casefold()
    stats_row([
        ("bits", f"{bloom.num_bits:,}"),
        ("hash functions", f"{bloom.num_hashes}"),
        ("words inserted", f"{bloom.item_count:,}"),
        ("bits set", f"{sum(bloom.bit_array):,}"),
        ("theoretical false-positive rate", format_probability(bloom.calculate_false_positive_rate())),
    ])
    if not term:
        return
    probes = bloom._hash_indices(term)
    present = bloom.might_contain(term)
    actually = engine.trie.search(term)
    if present and actually:
        msg = verdict(True, f"“{escape(term)}”: all {len(probes)} bits set — possibly present, and the Trie confirms it", "")
    elif present:
        msg = '<span class="sl-verdict neutral">All bits set but the word is not indexed — a false positive</span>'
    else:
        missing = sum(1 for i in probes if not bloom.bit_array[i])
        msg = verdict(False, "", f"“{escape(term)}”: {missing} of {len(probes)} bits are empty — definitely absent")
    html(f'<div style="margin:.4rem 0 .8rem">{msg}</div>')
    section("Where the word lands", "The strip shows bit density across the whole array; marked lines are this word's "
                                    "hash positions. One empty bit is enough to rule it out.")
    html(diagrams.bloom_svg(bloom.bit_array, probes, present))


# --------------------------------------------------------------------------- #
# Benchmark lab
# --------------------------------------------------------------------------- #
def render_benchmark(engine: SearchEngine) -> None:
    header("Benchmark lab", "Grow the text or the pattern while holding the other fixed, and compare median runtimes and "
                            "operation counts for KMP, Rabin–Karp and Horspool.")
    with st.container(border=True):
        c = st.columns([1, 1.4, 1, .9])
        max_text = c[0].selectbox("Largest text", ("100 KB", "500 KB", "1 MB"))
        pattern_sizes = c[1].multiselect("Pattern lengths", (3, 5, 10, 20, 50), default=[3, 5, 10, 20, 50])
        source_mode = c[2].selectbox("Text source", ("Active corpus", "Controlled fixture"),
                                     help="Active corpus repeats your documents to the exact size.")
        repeats = c[3].slider("Repeats (median)", 3, 9, 5, step=2)
        c2 = st.columns([2, 1, 1])
        fixed_pattern = c2[0].text_input("Pattern for the text-size study", value="algorithm")
        run_text = c2[1].checkbox("Text-size study", value=True)
        run_patterns = c2[2].checkbox("Pattern-length study", value=True)
        start = st.button("Run experiments", type="primary")

    if start:
        if not (run_text or run_patterns):
            st.warning("Choose at least one study.")
        elif not fixed_pattern.strip():
            st.warning("Enter a pattern for the text-size study.")
        else:
            sizes = {"100 KB": [1_024, 5_120, 10_240, 51_200, 102_400],
                     "500 KB": [1_024, 5_120, 10_240, 51_200, 102_400, 512_000],
                     "1 MB": [1_024, 5_120, 10_240, 51_200, 102_400, 512_000, 1_048_576]}[max_text]
            source = "\n".join(d.original_text for d in engine.documents) if source_mode == "Active corpus" else None
            with st.spinner("Measuring…"):
                text_rows = benchmark_text_sizes(sizes, fixed_pattern, repeats, source) if run_text else []
                pattern_rows = (benchmark_pattern_sizes(sizes[-1], pattern_sizes, repeats, source)
                                if run_patterns and pattern_sizes else [])
                bloom = benchmark_bloom_filter("algorithm data structures search indexing performance",
                                               ["algorithm", "structures", "missingxyz", "quantumxyz"], repeats=repeats)
            st.session_state["benchmark_result"] = {
                "text_rows": text_rows, "pattern_rows": pattern_rows, "bloom": bloom, "max_text": max_text,
                "source_mode": source_mode, "query_pattern": fixed_pattern, "repeats": repeats,
                "run_time": datetime.now().astimezone().strftime("%Y-%m-%d %H:%M %Z"),
            }

    result = st.session_state.get("benchmark_result")
    if not result:
        html('<p class="sl-muted">Run the experiments to see curves here. Repeat a run before drawing conclusions — '
             "timings depend on your machine and background load.</p>")
        return

    rows = result["text_rows"] + result["pattern_rows"]
    stats_row([
        ("largest text", result["max_text"]),
        ("runs per point (median)", str(result["repeats"])),
        ("position agreement", "100%" if all(r["positions_agree"] for r in rows) else "check rows"),
        (f'completed {result["run_time"][:10]}', result["run_time"][11:16]),
    ])
    html(f'<p class="sl-muted">Python {platform.python_version()} on {platform.system()} {platform.release()} · '
         f'source: {result["source_mode"]}</p>')

    def melt(data: list[dict], x: str, kind: str) -> pd.DataFrame:
        frame = pd.DataFrame(data)
        frame["rk_ops"] = frame["hash_comparisons"] + frame["character_verifications"]
        cols = ({"kmp_time": "KMP", "rabin_karp_time": "Rabin–Karp", "horspool_time": "Horspool"} if kind == "time" else
                {"kmp_comparisons": "KMP", "rk_ops": "Rabin–Karp", "horspool_comparisons": "Horspool"})
        out = frame[[x, *cols]].rename(columns=cols).melt(id_vars=x, var_name="algorithm", value_name="value")
        out["value"] = out["value"].clip(lower=1e-9 if kind == "time" else 1)
        return out

    exports = []
    for rows_, x, title, label in (
        (result["text_rows"], "text_size", "Text size", "Text length (characters, log scale)"),
        (result["pattern_rows"], "pattern_size", "Pattern length", "Pattern length (characters)"),
    ):
        if not rows_:
            continue
        frame = pd.DataFrame(rows_)
        frame.insert(0, "experiment", x)
        exports.append(frame)
        section(f"{title} study", "Pattern held fixed while the text grows." if x == "text_size"
                else "Text held fixed while the probe pattern grows.")
        a, b = st.columns(2)
        with a:
            st.altair_chart(algo_chart(melt(rows_, x, "time"), x, label), use_container_width=True)
        with b:
            st.altair_chart(algo_chart(melt(rows_, x, "ops"), x, label, "Comparisons: chars, or hashes + checks (log)"),
                            use_container_width=True)
        with st.expander("Raw measurements"):
            st.dataframe(frame, hide_index=True, use_container_width=True)

    if exports:
        export = pd.concat(exports, ignore_index=True)
        for i, (k, v) in enumerate((("source", result["source_mode"]), ("largest_text_setting", result["max_text"]),
                                    ("median_repeats", result["repeats"]), ("fixed_query", result["query_pattern"]),
                                    ("run_time", result["run_time"]), ("python_version", platform.python_version()),
                                    ("operating_system", platform.system())), start=1):
            export.insert(i, k, v)
        st.download_button("Download measurements (CSV)", export.to_csv(index=False).encode("utf-8"),
                           file_name="string_search_performance.csv", mime="text/csv")
    section("Bloom filter pre-screening", "Time to answer four queries with and without the filter in front of KMP.")
    st.dataframe(pd.DataFrame([result["bloom"]]), hide_index=True, use_container_width=True)


# --------------------------------------------------------------------------- #
# Documents
# --------------------------------------------------------------------------- #
def render_documents(engine: SearchEngine) -> None:
    header("Documents", "Add text, TXT, PDF or DOCX files. They are saved to the local SQLite store and indexed into the "
                        "Trie, Bloom filter and BM25 index immediately.")
    left, right = st.columns(2)
    with left:
        with st.container(border=True):
            st.markdown("**Upload files** · up to 10 MiB each, PDFs up to 500 pages")
            uploads = st.file_uploader("Upload", type=["txt", "pdf", "docx"], accept_multiple_files=True,
                                       label_visibility="collapsed")
            for upload in uploads or []:
                try:
                    added = engine.add_document(upload.name, extract_text(upload.name, upload.getvalue()))
                    (st.success if added else st.info)(f"Indexed {upload.name}" if added else f"{upload.name} is already indexed")
                except (ValueError, UnicodeError) as error:
                    st.error(f"{upload.name}: {error}")
    with right:
        with st.form("paste_document"):
            st.markdown("**Paste text**")
            name = st.text_input("Document name", placeholder="research-notes.txt")
            content = st.text_area("Text", height=120)
            if st.form_submit_button("Add document"):
                if not name.strip() or not content.strip():
                    st.error("Enter both a document name and its text.")
                else:
                    name = name if Path(name).suffix else name + ".txt"
                    if Path(name).suffix.casefold() != ".txt":
                        st.error("Pasted text must use a .txt name.")
                    elif engine.add_document(name, content):
                        st.success(f"Added {name}.")
                        st.rerun()
                    else:
                        st.info("A document with this name or content is already indexed.")
    section("Indexed documents")
    frame = pd.DataFrame([{"Document": d.name, "Characters": len(d.original_text), "Words": len(d.tokens),
                           "Distinct terms": len(d.unique_terms)} for d in engine.documents])
    st.dataframe(frame, use_container_width=True, hide_index=True,
                 column_config={"Words": st.column_config.ProgressColumn("Words", format="%d", min_value=0,
                                                                         max_value=int(frame["Words"].max() or 1))})


# --------------------------------------------------------------------------- #
# History
# --------------------------------------------------------------------------- #
def render_history() -> None:
    header("Search history", "Queries, result counts and timings saved locally. Document text is never stored here.")
    store = Storage(DATABASE_PATH)
    rows = [dict(row) for row in store.history()]
    if not rows:
        st.info("Run a search and it will appear here.")
        return
    frame = pd.DataFrame(rows)
    stats_row([
        ("searches", f"{len(rows):,}"),
        ("found something", f"{int((frame.match_count > 0).sum()):,}"),
        ("found nothing", f"{int((frame.match_count == 0).sum()):,}"),
        ("average time", format_runtime(float(frame.elapsed_seconds.mean()))),
    ])
    counts = frame.groupby("query", as_index=False).size().sort_values("size", ascending=False).head(12)
    chart = alt.Chart(counts).mark_bar(color=PALETTE["ink"], cornerRadiusEnd=3, height=16).encode(
        x=alt.X("size:Q", title="times searched", axis=alt.Axis(tickMinStep=1, format="d")), y=alt.Y("query:N", sort="-x", title=None,
                                                          axis=alt.Axis(labelFont="IBM Plex Mono, Menlo, Consolas, monospace")),
    ).properties(height=max(120, 26 * len(counts))).configure_view(strokeWidth=0).configure_axis(gridColor="#E3E9F2")
    section("Most frequent queries")
    st.altair_chart(chart, use_container_width=True)
    section("All searches")
    st.dataframe(frame, use_container_width=True, hide_index=True)
    if st.button("Clear search history", type="secondary"):
        store.clear_history()
        st.rerun()


# --------------------------------------------------------------------------- #
# How it works
# --------------------------------------------------------------------------- #
def render_how() -> None:
    header("How it works", "The architecture, the query pipeline, and the cost of every structure and algorithm in it.")
    html(diagrams.architecture_svg())
    section("Query pipeline")
    html(
        '<ol style="max-width:72ch;line-height:1.7">'
        "<li><b>Normalise.</b> The query is case-folded and split into Unicode word tokens.</li>"
        "<li><b>Screen.</b> A single-word query that is neither in the Bloom filter nor a Trie prefix is rejected without "
        "scanning, and fuzzy Trie search offers corrections.</li>"
        "<li><b>Rank.</b> BM25 scores documents from the inverted index using term frequency, rarity and length.</li>"
        "<li><b>Verify.</b> KMP, Rabin–Karp and Horspool each scan the documents; the result is only trusted when all three "
        "return identical positions.</li>"
        "<li><b>Explain.</b> Highlighted context, operation counts and timings are shown, and the query is logged.</li></ol>"
    )
    section("Complexity reference", "n = text length, m = pattern length, σ = alphabet size, k = hash functions, z = matches.")
    rows = [
        ("Trie", "Prefix lookup, autocomplete", "<code>O(m)</code> + output", "<code>O(total chars)</code>"),
        ("Trie top-k", "Frequency-ranked completions", "<code>O(S log k)</code> over subtree S", "<code>O(k)</code>"),
        ("Fuzzy Trie", "Levenshtein ≤ d", "<code>O(nodes visited · m)</code>, pruned", "<code>O(m · depth)</code>"),
        ("KMP", "Exact match", "<code>O(n + m)</code>", "<code>O(m)</code>"),
        ("Rabin–Karp", "Exact match via rolling hash", "avg <code>O(n + m)</code>, worst <code>O(nm)</code>", "<code>O(1)</code>"),
        ("Boyer–Moore–Horspool", "Exact match with skips", "avg sub-linear, worst <code>O(nm)</code>", "<code>O(σ)</code>"),
        ("Aho–Corasick", "Many patterns at once", "<code>O(n + Σm + z)</code>", "<code>O(Σm · σ)</code>"),
        ("BM25", "Relevance ranking", "<code>O(postings of query terms)</code>", "<code>O(postings)</code>"),
        ("Bloom filter", "Membership pre-check", "<code>O(k)</code>", "<code>O(bits)</code>"),
    ]
    html('<table class="sl-table"><thead><tr><th>Technique</th><th>Used for</th><th>Time</th><th>Space</th></tr></thead><tbody>'
         + "".join(f"<tr><td><b>{a}</b></td><td>{b}</td><td>{c}</td><td>{d}</td></tr>" for a, b, c, d in rows)
         + "</tbody></table>")
    section("Limits worth stating")
    html('<p style="max-width:72ch">Timings are in-process Python and vary with hardware and load, so compare growth and '
         "operation counts rather than single runs. PDF extraction needs embedded text (no OCR). The SQLite store is local "
         "and unencrypted; treat it as sensitive if your documents are.</p>")


# --------------------------------------------------------------------------- #
# main
# --------------------------------------------------------------------------- #
def main() -> None:
    st.set_page_config(page_title="StringLab", page_icon="🔎", layout="wide")
    html(CSS)
    try:
        engine = load_engine()
    except (OSError, ValueError) as error:
        st.error(f"Could not load documents: {error}")
        return

    with st.sidebar:
        html('<div class="sl-brand"><span class="sl-brand-mark">S|L</span><div>'
             '<div class="sl-brand-name">StringLab</div>'
             '<div class="sl-brand-sub">String matching & retrieval studio</div></div></div>')
        st.session_state.setdefault("nav", PAGES[0])
        page = st.radio("Navigate", PAGES, key="nav", label_visibility="collapsed")
        html(f'<div class="sl-side-note"><b>{engine.document_count} documents</b> indexed<br>'
             f'<span>{engine.indexed_term_count:,} terms · {engine.trie.node_count:,} Trie nodes<br>'
             "Stored locally in SQLite</span></div>")

    {
        "Overview": lambda: render_overview(engine),
        "Search": lambda: render_search(engine),
        "Trie explorer": lambda: render_trie(engine),
        "Multi-pattern scan": lambda: render_multi_pattern(engine),
        "Algorithm internals": lambda: render_internals(engine),
        "Bloom filter": lambda: render_bloom(engine),
        "Benchmark lab": lambda: render_benchmark(engine),
        "Documents": lambda: render_documents(engine),
        "Search history": render_history,
        "How it works": render_how,
    }[page]()


if __name__ == "__main__":
    main()
