"""Streamlit interface for the String Search Performance Studio."""

from __future__ import annotations

from pathlib import Path
from datetime import datetime
import platform

import matplotlib.pyplot as plt
import pandas as pd
import streamlit as st

from core.benchmark import (
    benchmark_bloom_filter,
    benchmark_pattern_sizes,
    benchmark_text_sizes,
)
from core.search_engine import SearchEngine
from core.ingestion import extract_text
from core.storage import Storage


PROJECT_ROOT = Path(__file__).resolve().parent
DOCUMENTS_DIRECTORY = PROJECT_ROOT / "data" / "sample_documents"


def inject_styles() -> None:
    """Apply the presentation layer without changing Streamlit flow."""
    st.markdown(
        """
        <style>
        :root {
            --ink: #17243d;
            --muted: #5d6b83;
            --blue: #315fbd;
            --blue-dark: #23468e;
            --blue-soft: #edf3ff;
            --purple: #7656bd;
            --line: #dce3ee;
            --canvas: #f5f7fb;
            --green: #16734d;
            --green-soft: #e8f6ef;
            --amber: #8a5d12;
            --amber-soft: #fff5dd;
        }

        .stApp, [data-testid='stAppViewContainer'] {
            background: var(--canvas);
            color: var(--ink);
            font-family: 'Plus Jakarta Sans', sans-serif;
        }
        [data-testid='stHeader'] { background: transparent; }
        [data-testid='stSidebar'] {
            background: #ffffff;
            border-right: 1px solid var(--line);
        }
        [data-testid='stSidebar'] > div:first-child { padding-top: 1.25rem; }
        [data-testid='stSidebar'] * { color: var(--ink); }
        [data-testid='stSidebar'] .stRadio label {
            border-radius: 13px;
            padding: 0.62rem 0.78rem;
            margin: 0.16rem 0;
            transition: background 160ms ease, transform 160ms ease;
        }
        [data-testid='stSidebar'] .stRadio label:hover {
            background: var(--blue-soft);
            transform: translateX(3px);
        }
        [data-testid='stSidebar'] [role='radiogroup'] {
            gap: 0.12rem;
        }
        .brand-mark {
            width: 44px; height: 44px; border-radius: 14px;
            display: grid; place-items: center;
            background: var(--blue-soft);
            border: 1px solid #d5e2fb;
            color: var(--blue);
            font-size: 1.35rem; margin-bottom: 1rem;
        }
        .brand-title { font: 800 1.02rem/1.2 'Space Grotesk', sans-serif; }
        .brand-subtitle { color: var(--muted); font-size: .72rem; margin-top: .55rem; }
        .sidebar-status {
            margin-top: 2rem; padding: .9rem; border-radius: 16px;
            background: #f7f9fc;
            border: 1px solid var(--line);
            font-size: .78rem;
        }
        .status-dot {
            display: inline-block; width: 8px; height: 8px;
            border-radius: 50%; background: #2eaa70; margin-right: 6px;
        }
        .topbar {
            display: flex; justify-content: space-between; align-items: end;
            padding: .35rem 0 1.35rem; border-bottom: 1px solid var(--line);
            margin-bottom: 1.8rem;
        }
        .eyebrow { color: var(--blue); text-transform: uppercase;
            letter-spacing: .12em; font-size: .68rem; font-weight: 700; }
        .page-title { color: var(--ink); font: 800 1.9rem/1.1 'Space Grotesk', sans-serif;
            letter-spacing: -.035em; margin-top: .35rem; }
        .page-subtitle { color: var(--muted); font-size: .88rem; margin-top: .45rem; }
        .section-kicker { color: var(--muted); font-size: .75rem;
            letter-spacing: .08em; text-transform: uppercase; font-weight: 700;
            margin: 1.4rem 0 .65rem; }
        .hero-card, .surface-card {
            background: #fff; border: 1px solid var(--line); border-radius: 20px;
            padding: 1.25rem 1.35rem; box-shadow: 0 12px 30px rgba(58, 35, 111, .06);
        }
        .hero-card { background: linear-gradient(135deg, #fff 0%, #eef4ff 100%); }
        .kpi-label { color: var(--muted); font-size: .75rem; font-weight: 600; }
        .kpi-value { color: var(--ink); font: 800 1.7rem 'Space Grotesk', sans-serif; margin-top: .35rem; }
        .kpi-icon { color: var(--blue); font-size: 1.25rem; float: right; }
        .metric-card {
            background: #fff; border: 1px solid var(--line); border-radius: 16px;
            padding: .85rem 1rem; min-height: 74px;
        }
        .metric-card b { display: block; color: var(--ink); font-size: 1.05rem; margin-top: .25rem; }
        .success-card { background: var(--green-soft); border: 1px solid #bfe6d1;
            border-radius: 16px; color: var(--green); padding: .9rem 1rem; }
        .warning-card { background: var(--amber-soft); border: 1px solid #eedaa8;
            border-radius: 16px; color: var(--amber); padding: .9rem 1rem; }
        .match-context { background: #f8faff; border: 1px solid var(--line);
            border-radius: 13px; padding: .9rem 1rem; color: var(--ink);
            white-space: pre-wrap; font: .84rem/1.65 'Plus Jakarta Sans', sans-serif;
            margin: .45rem 0 .8rem; }
        .search-highlight { background: #ffe08a; color: #17243d;
            border-radius: 4px; padding: 0 3px; font-weight: 700; }
        div.stButton > button, div[data-testid='stFormSubmitButton'] button {
            border: 0; border-radius: 10px; background: var(--blue);
            color: white; font-weight: 700; padding: .58rem 1.05rem;
            box-shadow: 0 5px 14px rgba(49, 95, 189, .18);
            transition: transform 160ms ease, box-shadow 160ms ease;
        }
        div.stButton > button:hover { transform: translateY(-1px);
            box-shadow: 0 8px 18px rgba(49, 95, 189, .25); color: white; }
        input, textarea, [data-baseweb='select'] > div {
            border-radius: 12px !important; border-color: var(--line) !important;
            background: #fff !important;
        }
        [data-testid='stMetric'] { background: #fff; border: 1px solid var(--line);
            border-radius: 16px; padding: 1rem; box-shadow: 0 8px 22px rgba(58,35,111,.045); }
        [data-testid='stMetricLabel'] { color: var(--muted); }
        [data-testid='stMetricValue'] { color: var(--ink); font-family: 'Space Grotesk', sans-serif; }
        [data-testid='stExpander'] { border: 1px solid var(--line); border-radius: 16px;
            background: #fff; margin: .65rem 0; overflow: hidden; }
        [data-testid='stDataFrame'] { border: 1px solid var(--line); border-radius: 14px; overflow: hidden; }
        .stCaption { color: var(--muted); }
        @media (max-width: 800px) {
            .page-title { font-size: 1.45rem; }
            .topbar { align-items: start; }
            .hero-card, .surface-card { padding: 1rem; }
        }

        /* Compact dashboard rhythm and restrained SaaS typography. */
        html, body, [class*='css'] {
            font-family: system-ui, -apple-system, 'Segoe UI', sans-serif;
        }
        [data-testid='stSidebar'] { min-width: 240px; max-width: 240px; }
        [data-testid='stSidebar'] > div:first-child { padding: 1rem .85rem; }
        [data-testid='stSidebar'] .stRadio label {
            min-height: 40px;
            padding: .48rem .7rem;
            margin: .08rem 0;
            font-size: .8rem;
        }
        .brand-mark { width: 38px; height: 38px; border-radius: 11px;
            margin-bottom: .65rem; font-size: 1.1rem; }
        .brand-title { font-family: 'Inter', sans-serif; font-size: .92rem;
            font-weight: 700; }
        .brand-subtitle { margin-top: .35rem; font-size: .68rem; }
        .sidebar-status { margin-top: 1.25rem; padding: .72rem;
            border-radius: 12px; font-size: .7rem; }
        .main .block-container, [data-testid='stAppViewContainer'] .block-container {
            max-width: 1220px;
            padding: 2rem 2.75rem 3rem;
        }
        .page-title { font-family: 'Inter', sans-serif; font-size: 1.75rem;
            line-height: 1.2; font-weight: 650; letter-spacing: -.025em;
            margin-top: .22rem; }
        .page-subtitle { font-size: .8rem; line-height: 1.45;
            margin-top: .28rem; }
        .eyebrow { font-size: .62rem; letter-spacing: .1em; }
        .section-kicker { font-size: .66rem; margin: 1.15rem 0 .5rem; }
        .hero-card, .surface-card { border-radius: 16px; padding: 1rem 1.1rem;
            box-shadow: 0 4px 18px rgba(58, 35, 111, .045); }
        [data-testid='stHorizontalBlock'] { gap: .8rem; }
        [data-testid='stMetric'] { min-height: 94px; padding: .78rem .9rem;
            border-radius: 14px; box-shadow: 0 4px 18px rgba(58,35,111,.035); }
        [data-testid='stMetricLabel'] { font-size: .72rem; }
        [data-testid='stMetricValue'] { font-size: 1.35rem; }
        [data-testid='stExpander'] { margin: .4rem 0; border-radius: 13px; }
        .match-context { padding: .72rem .85rem; margin: .3rem 0 .55rem;
            font-size: .78rem; line-height: 1.5; border-radius: 11px; }
        .stMarkdown p { margin-bottom: .45rem; }
        div[data-testid='stTextInput'] { margin-bottom: .35rem; }
        div.stButton > button { min-height: 38px; padding: .45rem .9rem;
            border-radius: 10px; font-size: .78rem; }
        [data-testid='stDataFrame'] { border-radius: 12px; }
        [data-testid='stDataFrame'] * { font-size: .76rem; }
        [data-testid='stImage'] img, .element-container iframe {
            max-height: 360px;
        }
        @media (max-width: 800px) {
            [data-testid='stSidebar'] { min-width: 0; max-width: 100%; }
            .main .block-container, [data-testid='stAppViewContainer'] .block-container {
                padding: 1.25rem 1rem 2rem;
            }
            .page-title { font-size: 1.45rem; }
        }

        .stMarkdown, [data-testid='stMarkdownContainer'] p,
        [data-testid='stText'], label { color: var(--ink); }
        [data-testid='stSidebar'] .stRadio label { color: var(--ink); }
        [data-testid='stExpander'] summary p { color: var(--ink); }
        .algorithm-chip { display: inline-block; color: var(--blue-dark);
            background: var(--blue-soft); border: 1px solid #d5e2fb;
            border-radius: 999px; padding: .25rem .55rem; font-size: .72rem;
            font-weight: 700; margin: .15rem .2rem .15rem 0; }
        .workflow-node { flex: 1; min-width: 120px; text-align: center;
            padding: .9rem .6rem; background: #fff; border: 1px solid var(--line);
            border-radius: 12px; font-weight: 700; color: var(--ink); }
        .workflow-arrow { align-self: center; color: var(--blue); font-size: 1.2rem; }
        .result-stat { color: var(--muted); font-size: .76rem; }
        /* StringLab visual system: ink, paper and signal green. */
        :root {
            --ink: #16231f; --muted: #64736c; --blue: #176b54;
            --blue-dark: #10533f; --blue-soft: #e7f2ed;
            --purple: #8b6b43; --line: #d9e3dc; --canvas: #f4f6f2;
            --green: #176b54; --green-soft: #e7f2ed;
            --amber: #875d1f; --amber-soft: #fbf2df;
        }
        .stApp, [data-testid='stAppViewContainer'] { background:var(--canvas); }
        [data-testid='stSidebar'] { background:#172923; border-right:0; }
        [data-testid='stSidebar'] * { color:#eff5f0 !important; }
        [data-testid='stSidebar'] [role='radiogroup'] label {
            color:#d8e5dc !important; border-radius:9px; padding:.52rem .7rem;
        }
        [data-testid='stSidebar'] [role='radiogroup'] label:hover,
        [data-testid='stSidebar'] [role='radiogroup'] label:has(input:checked) {
            background:#29483b; color:#fff !important;
        }
        .brand-mark { width:40px;height:40px;border-radius:11px;
            background:#28483b;border:1px solid #426351;color:#b9e3c5; }
        .brand-title { color:#fff;font-family:'Space Grotesk',sans-serif;
            font-size:1rem;letter-spacing:.015em; }
        .brand-subtitle { color:#aebfb2 !important; }
        .sidebar-status { background:#20382e;border:1px solid #365342;color:#e7f2e9; }
        .sidebar-status span { color:#bdd0c2 !important; }
        .main .block-container { max-width:1320px;padding-top:1.65rem; }
        .page-title { color:var(--ink); }
        .eyebrow { color:var(--blue); }
        .hero-card { color:#f5f7f1;background:linear-gradient(120deg,#172923 0%,#264638 100%);
            border:1px solid #304d3e;box-shadow:0 15px 34px rgba(23,41,35,.12); }
        .hero-card .page-title,.hero-card .page-subtitle,.hero-card .eyebrow { color:#f5f7f1; }
        .hero-card .eyebrow { color:#b8dfc5; }
        .hero-card .algorithm-chip { color:#e4f1e7;background:#365745;border-color:#517260; }
        .surface-card,.metric-card,[data-testid='stMetric'] { box-shadow:0 5px 20px rgba(31,55,43,.035); }
        div.stButton > button,div[data-testid='stFormSubmitButton'] button {
            background:#176b54;box-shadow:none;border-radius:9px; }
        div.stButton > button:hover { background:#10533f;box-shadow:none; }
        [data-testid='stMetric'] { border-radius:12px; }
        [data-testid='stMetricValue'] { font-family:'Space Grotesk',sans-serif; }
        [data-testid='stExpander'] { border-radius:12px; }
        .study-banner { display:flex;gap:.75rem;align-items:center;justify-content:space-between;
            padding:.65rem .85rem;margin-bottom:1.15rem;border:1px solid var(--line);
            border-radius:11px;background:#fff;color:var(--muted);font-size:.72rem; }
        .study-banner b { color:var(--ink);letter-spacing:.04em; }
        .hero-grid { display:grid;grid-template-columns:1.25fr .75fr;gap:1.25rem;align-items:end; }
        .hero-aside { border-left:1px solid #557060;padding-left:1rem;color:#deebe0;font-size:.77rem;line-height:1.8; }
        .hero-aside b { color:#b8dfc5; }
        .evidence-note { border-left:3px solid #74a98a;padding:.65rem .85rem;
            background:#edf4ef;border-radius:0 9px 9px 0;color:#46584d;font-size:.78rem; }
        .workflow-node { border-radius:11px;background:#fff; }
        .workflow-node small { color:var(--muted);font-weight:500; }
        @media(max-width:800px){.hero-grid{grid-template-columns:1fr}.hero-aside{border-left:0;border-top:1px solid #557060;padding:.7rem 0 0}}
        </style>
        """,
        unsafe_allow_html=True,
    )


def format_probability(probability: float) -> str:
    """Format a probability without hiding a small non-zero value."""
    if probability == 0:
        return "0%"
    if probability < 0.0001:
        return f"{probability:.6e}"
    return f"{probability:.4%}"


def format_runtime(seconds: float) -> str:
    """Format short algorithm timings in readable engineering units."""
    if seconds < 0.001:
        return f"{seconds * 1_000_000:.2f} µs"
    if seconds < 1:
        return f"{seconds * 1_000:.2f} ms"
    return f"{seconds:.3f} s"


@st.cache_resource
def load_engine() -> SearchEngine:
    """Build the document indexes once per Streamlit process."""
    return SearchEngine(DOCUMENTS_DIRECTORY, storage_path=PROJECT_ROOT / "data" / "stringlab.sqlite3")


def render_document_uploader(engine: SearchEngine) -> None:
    """Render an optional in-memory text-document uploader."""
    st.sidebar.markdown("**Add a text document**")
    uploaded_file = st.sidebar.file_uploader(
        "Upload .txt",
        type=["txt"],
        key="uploaded_text_document",
        label_visibility="collapsed",
    )
    if uploaded_file is None:
        return

    try:
        document_text = uploaded_file.getvalue().decode("utf-8")
        added = engine.add_document(uploaded_file.name, document_text)
    except (UnicodeDecodeError, TypeError, ValueError) as error:
        st.sidebar.error(str(error))
        return

    if added:
        st.sidebar.success(
            f"Added {uploaded_file.name}. "
            f"Documents indexed: {engine.document_count}."
        )
    else:
        st.sidebar.info(f"{uploaded_file.name} is already indexed.")


def render_dashboard(engine: SearchEngine) -> None:
    false_positive_rate = engine.bloom_filter.calculate_false_positive_rate()
    st.markdown(
        '<div class="hero-card"><div class="hero-grid"><div><div class="eyebrow">Micro Project 10 · Information Retrieval</div>'
        '<div class="page-title">String Search<br>Performance Studio</div>'
        '<div class="page-subtitle">A working laboratory for measuring exact string-matching and retrieval techniques on text corpora.</div>'
        '<div style="margin-top:.8rem"><span class="algorithm-chip">Trie · prefix retrieval</span>'
        '<span class="algorithm-chip">KMP · prefix-function matching</span>'
        '<span class="algorithm-chip">Rabin–Karp · rolling hash</span></div></div>'
        '<div class="hero-aside"><b>Research focus</b><br>Text analytics · information retrieval · string algorithms<br>'
        '<b>Study method</b><br>Vary corpus size and pattern length; record runtime, comparisons and position agreement.</div></div></div>',
        unsafe_allow_html=True,
    )
    st.markdown('<div class="section-kicker">Live system status</div>', unsafe_allow_html=True)
    columns = st.columns(5)
    for column, label, value in zip(
        columns,
        ("Documents", "Unique words", "Trie status", "Bloom Filter", "Search Engine"),
        (engine.document_count, engine.indexed_term_count, "Ready", "Ready", "Ready"),
    ):
        column.metric(label, value)
    total_characters = sum(len(document.original_text) for document in engine.documents)
    total_tokens = sum(len(document.tokens) for document in engine.documents)
    st.markdown('<div class="section-kicker">Corpus profile</div>', unsafe_allow_html=True)
    corpus_columns = st.columns(3)
    corpus_columns[0].metric("Corpus characters", f"{total_characters:,}")
    corpus_columns[1].metric("Token count", f"{total_tokens:,}")
    corpus_columns[2].metric("Unique indexed terms", f"{engine.indexed_term_count:,}")
    st.markdown('<div class="section-kicker">Core index profile</div>', unsafe_allow_html=True)
    info_columns = st.columns(4)
    info_columns[0].metric("Bits", f"{engine.bloom_filter.num_bits:,}")
    info_columns[1].metric("Hash functions", engine.bloom_filter.num_hashes)
    info_columns[2].metric("Inserted terms", engine.bloom_filter.item_count)
    info_columns[3].metric(
        "Estimated false positives",
        format_probability(false_positive_rate),
    )
    st.caption(
        f"{engine.bloom_filter.num_bits:,} bits, "
        f"{engine.bloom_filter.num_hashes} hash functions, "
        f"theoretical false-positive rate "
        f"{format_probability(false_positive_rate)}."
    )
    st.markdown('<div class="section-kicker">How the algorithms cooperate</div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="surface-card"><div style="display:flex;gap:.55rem;align-items:stretch;flex-wrap:wrap">'
        '<div class="workflow-node">Text<br><small>documents</small></div><div class="workflow-arrow">→</div>'
        '<div class="workflow-node">Trie + Bloom Filter<br><small>index & screen</small></div><div class="workflow-arrow">→</div>'
        '<div class="workflow-node">KMP + Rabin-Karp<br><small>exact matching</small></div><div class="workflow-arrow">→</div>'
        '<div class="workflow-node">Results<br><small>evidence & metrics</small></div></div></div>',
        unsafe_allow_html=True,
    )
    st.markdown('<div class="section-kicker">Project scope</div>', unsafe_allow_html=True)
    scope_columns = st.columns(3)
    for column, number, title, detail in zip(
        scope_columns,
        ("01", "02", "03"),
        ("Design scenarios", "Measure behavior", "Guide selection"),
        (
            "Vary text length and pattern characteristics.",
            "Compare KMP and Rabin–Karp runtime and operation counts.",
            "Use input shape and measured evidence to discuss suitability.",
        ),
    ):
        column.markdown(
            f'<div class="metric-card"><span class="result-stat">PROJECT SCOPE · {number}</span>'
            f'<b style="display:block;margin:.35rem 0">{title}</b><span class="result-stat">{detail}</span></div>',
            unsafe_allow_html=True,
        )
    st.markdown(
        '<div class="success-card" style="margin-top:.8rem"><b>Corpus ready for study</b><br>'
        'Search and benchmark local text files. Upload another .txt file in the sidebar to extend this in-memory session corpus.</div>',
        unsafe_allow_html=True,
    )


def render_autocomplete(engine: SearchEngine) -> None:
    st.markdown(
        '<div class="eyebrow">Prefix retrieval · Trie</div>'
        '<div class="page-title">Trie Explorer</div>'
        '<div class="page-subtitle">Inspect prefix-based retrieval over the active corpus index.</div>',
        unsafe_allow_html=True,
    )
    st.markdown('<div class="surface-card">', unsafe_allow_html=True)
    st.markdown('<div class="section-kicker">Trie prefix search</div>', unsafe_allow_html=True)
    prefix = st.text_input("Enter a prefix", placeholder="Try alg, data, or search", key="autocomplete_prefix")
    limit = st.slider("Suggestion limit", min_value=1, max_value=25, value=10)
    st.markdown('</div>', unsafe_allow_html=True)
    if prefix:
        suggestions = engine.autocomplete(prefix, limit)
        st.markdown('<div class="section-kicker">Returned suggestions</div>', unsafe_allow_html=True)
        if suggestions:
            st.success(f"Trie status: Prefix found | {len(suggestions)} suggestions")
            suggestion_columns = st.columns(min(3, len(suggestions)))
            for index, suggestion in enumerate(suggestions):
                suggestion_columns[index % len(suggestion_columns)].markdown(
                    f'<div class="metric-card"><span class="result-stat">Suggestion {index + 1}</span><b>{suggestion}</b></div>',
                    unsafe_allow_html=True,
                )
        else:
            st.info("Trie status: Prefix not found")


def _render_search_results(search_result: dict[str, object]) -> None:
    results = search_result["results"]
    if not results:
        st.info("No indexed documents contain this query.")
        return
    for document_result in results:
        with st.expander(
            f"{document_result['document']}  ·  {len(document_result['kmp_positions'])} match(es)",
            expanded=True,
        ):
            algorithm_columns = st.columns(2)
            algorithm_columns[0].markdown(
                f'<div class="metric-card"><span class="result-stat">KMP · exact pattern search</span>'
                f'<b>{format_runtime(document_result["kmp_time"])}</b>'
                f'<span class="result-stat">{document_result["kmp_comparisons"]} character comparisons</span></div>',
                unsafe_allow_html=True,
            )
            algorithm_columns[1].markdown(
                f'<div class="metric-card"><span class="result-stat">Rabin-Karp · rolling hash</span>'
                f'<b>{format_runtime(document_result["rabin_karp_time"])}</b>'
                f'<span class="result-stat">{document_result["hash_comparisons"]} hash comparisons · '
                f'{document_result["character_verifications"]} verifications</span></div>',
                unsafe_allow_html=True,
            )
            st.markdown('<div class="section-kicker">Match positions and context</div>', unsafe_allow_html=True)
            st.caption(
                f"KMP positions: {document_result['kmp_positions']}  ·  "
                f"Rabin-Karp positions: {document_result['rabin_karp_positions']}"
            )
            for index, (position, context) in enumerate(
                zip(
                    document_result["kmp_positions"],
                    document_result["highlighted_contexts"],
                ),
                start=1,
            ):
                st.write(f"Match {index} at position {position}")
                st.markdown(
                    '<div class="match-context" '
                    'style="white-space:pre-wrap;">'
                    f"{context}</div>",
                    unsafe_allow_html=True,
                )


def render_text_search(engine: SearchEngine) -> None:
    st.markdown(
        '<div class="eyebrow">Exact matching · KMP + Rabin–Karp</div>'
        '<div class="page-title">Corpus Search</div>'
        '<div class="page-subtitle">Retrieve exact occurrences across the active text corpus and inspect algorithm agreement, operation counts and match context.</div>',
        unsafe_allow_html=True,
    )
    st.markdown('<div class="surface-card">', unsafe_allow_html=True)
    st.markdown('<div class="section-kicker">Search indexed documents</div>', unsafe_allow_html=True)
    query = st.text_input("Search query", placeholder="Try algorithm, data structures, or rolling hash", key="search_query")
    algorithm = st.selectbox(
        "Display algorithm",
        ("Both", "KMP", "Rabin-Karp"),
    )
    if st.button("Search", type="primary"):
        if not query.strip():
            st.warning("Enter a non-empty query.")
        else:
            st.session_state["last_search"] = engine.search(query)
    st.markdown('</div>', unsafe_allow_html=True)

    search_result = st.session_state.get("last_search")
    if not search_result:
        return
    if "execution_time" in search_result:
        st.caption(f"End-to-end search: {format_runtime(search_result['execution_time'])} · {search_result.get('match_count', 0)} exact occurrence(s)")
    st.markdown('<div class="section-kicker">Pattern matching results</div>', unsafe_allow_html=True)
    st.markdown(f'<div class="surface-card"><b>Query:</b> {search_result["query"]}<br>'
                f'<span class="result-stat">Bloom Filter: {search_result["bloom_filter"]["status"]} · '
                f'Exact pattern matching executed: {search_result["search_executed"]}</span></div>',
                unsafe_allow_html=True)
    if search_result["algorithms_agree"]:
        st.success("Algorithm Validation: PASSED")
    else:
        st.error("Algorithm Validation: FAILED")
        st.write(search_result["validation_error"])
    if algorithm == "Both":
        _render_search_results(search_result)
    else:
        for result in search_result["results"]:
            key = (
                "kmp_positions"
                if algorithm == "KMP"
                else "rabin_karp_positions"
            )
            st.markdown(
                f'<div class="metric-card"><span class="result-stat">{result["document"]}</span>'
                f'<b>{result[key]}</b></div>',
                unsafe_allow_html=True,
            )


def render_algorithm_comparison(engine: SearchEngine) -> None:
    st.markdown(
        '<div class="eyebrow">Performance lab</div>'
        '<div class="page-title">Algorithm Comparison</div>'
        '<div class="page-subtitle">Review each component’s role and compare independently measured results from the latest search.</div>',
        unsafe_allow_html=True,
    )
    st.markdown('<div class="section-kicker">Algorithm roles</div>', unsafe_allow_html=True)
    role_columns = st.columns(4)
    roles = (
        ("Trie", "Autocomplete", "Character-by-character prefix traversal"),
        ("KMP", "Exact search", "LPS-guided pattern matching"),
        ("Rabin-Karp", "Exact search", "Rolling hash with verification"),
        ("Bloom Filter", "Membership", "Fast term-level preliminary check"),
    )
    for column, (name, purpose, operation) in zip(role_columns, roles):
        column.markdown(
            f'<div class="surface-card"><span class="eyebrow">{purpose}</span>'
            f'<div class="page-title" style="font-size:1.1rem;margin-top:.35rem">{name}</div>'
            f'<p class="result-stat">{operation}</p></div>',
            unsafe_allow_html=True,
        )
    search_result = st.session_state.get("last_search")
    if not search_result or not search_result["results"]:
        st.info("Run a search with matching documents to populate the measured comparison.")
        return
    rows: list[dict[str, object]] = []
    for result in search_result["results"]:
        rows.extend(
            [
                {
                    "Document": result["document"],
                    "Metric": "Execution time (seconds)",
                    "KMP": result["kmp_time"],
                    "Rabin-Karp": result["rabin_karp_time"],
                },
                {
                    "Document": result["document"],
                    "Metric": "Matches",
                    "KMP": result["kmp_positions"],
                    "Rabin-Karp": result["rabin_karp_positions"],
                },
                {
                    "Document": result["document"],
                    "Metric": "Character comparisons",
                    "KMP": result["kmp_comparisons"],
                    "Rabin-Karp": "-",
                },
                {
                    "Document": result["document"],
                    "Metric": "Hash comparisons",
                    "KMP": "-",
                    "Rabin-Karp": result["hash_comparisons"],
                },
                {
                    "Document": result["document"],
                    "Metric": "Character verifications",
                    "KMP": "-",
                    "Rabin-Karp": result["character_verifications"],
                },
            ]
        )
    st.markdown('<div class="section-kicker">Latest exact-search measurements</div>', unsafe_allow_html=True)
    st.dataframe(pd.DataFrame(rows), hide_index=True, use_container_width=True)
    st.caption(
        f"Trie currently indexes {engine.indexed_term_count:,} unique terms. "
        f"Bloom Filter stores {engine.bloom_filter.item_count:,} terms in "
        f"{engine.bloom_filter.num_bits:,} bits."
    )
    if search_result["algorithms_agree"]:
        st.success("Validation: Results Match")
    else:
        st.error("Validation: Algorithm results differ")
        st.write("KMP and Rabin-Karp positions must be inspected.")


def render_bloom_analysis(engine: SearchEngine) -> None:
    st.markdown(
        '<div class="eyebrow">Probabilistic indexing</div>'
        '<div class="page-title">Bloom Filter Analysis</div>'
        '<div class="page-subtitle">Understand preliminary membership checks before exact retrieval.</div>',
        unsafe_allow_html=True,
    )
    search_result = st.session_state.get("last_search")
    if not search_result:
        st.info("Run a text search to inspect preliminary filtering.")
        return
    st.markdown(
        f'<div class="surface-card"><b>Query:</b> {search_result["query"]}<br>'
        f'<span class="result-stat">{search_result["bloom_filter"]["status"]} · '
        f'exact search: {search_result["search_executed"]} · '
        f'KMP: {search_result["kmp_executed"]} · '
        f'Rabin-Karp: {search_result["rabin_karp_executed"]}</span></div>',
        unsafe_allow_html=True,
    )
    bloom_columns = st.columns(4)
    bloom_columns[0].metric("Bits", search_result["bloom_filter"]["bits"])
    bloom_columns[1].metric(
        "Hash functions", search_result["bloom_filter"]["hash_functions"]
    )
    bloom_columns[2].metric(
        "Inserted items", search_result["bloom_filter"]["inserted_items"]
    )
    bloom_columns[3].metric(
        "Theoretical false-positive probability",
        format_probability(
            search_result["bloom_filter"]["false_positive_rate"]
        ),
    )
    if not search_result["search_executed"]:
        st.info("The term-level preliminary check eliminated this query before exact matching.")
    else:
        st.success("The query passed preliminary screening and was verified by exact matching.")
    st.caption(
        "A positive Bloom Filter result means possibly present, never proven "
        "present. KMP and Rabin-Karp provide exact verification."
    )
    st.metric("Indexed terms", engine.indexed_term_count)


def _plot_algorithm_times(rows: list[dict[str, object]], x_key: str) -> None:
    frame = pd.DataFrame(rows)
    figure, axis = plt.subplots(figsize=(8, 3.4))
    figure.patch.set_facecolor("#ffffff")
    axis.set_facecolor("#ffffff")
    axis.plot(frame[x_key], frame["kmp_time"], marker="o", linewidth=2.2, color="#176b54", label="KMP")
    axis.plot(
        frame[x_key],
        frame["rabin_karp_time"],
        marker="o",
        linewidth=2,
        color="#bd7a3a",
        label="Rabin-Karp",
    )
    axis.set_xlabel("Text length (characters)" if x_key == "text_size" else "Pattern length (characters)")
    axis.set_ylabel("Median runtime (seconds · log scale)")
    axis.set_yscale("log")
    axis.legend()
    axis.grid(alpha=0.2, color="#94a3b8", which="both")
    axis.spines[["top", "right"]].set_visible(False)
    axis.tick_params(colors="#5d6b83")
    axis.xaxis.label.set_color("#17243d")
    axis.yaxis.label.set_color("#17243d")
    axis.legend(frameon=False, loc="upper left")
    figure.tight_layout()
    st.pyplot(figure)
    plt.close(figure)


def render_benchmark(engine: SearchEngine) -> None:
    st.markdown(
        '<div class="eyebrow">Experimental workspace</div>'
        '<div class="page-title">Benchmark Lab</div>'
        '<div class="page-subtitle">Control input scale and repetition count, then compare measured KMP and Rabin–Karp performance.</div>',
        unsafe_allow_html=True,
    )
    with st.container(border=True):
        st.markdown("**Experiment design**")
        control_cols = st.columns([1.15, 1.15, 1.15, .8])
        with control_cols[0]:
            max_text = st.selectbox(
                "Largest corpus",
                ("100 KB", "500 KB", "1 MB"),
                index=0,
                help="The experiment runs the selected scale and each smaller checkpoint.",
            )
        with control_cols[1]:
            pattern_sizes = st.multiselect(
                "Pattern lengths (characters)",
                (3, 5, 10, 20, 50),
                default=[3, 5, 10, 20, 50],
            )
        with control_cols[2]:
            source_mode = st.selectbox(
                "Text source",
                ("Active corpus", "Controlled fixture"),
                help="The active corpus combines sample files and uploaded text. It is repeated to the selected exact size for scale comparisons.",
            )
        with control_cols[3]:
            repeats = st.slider("Median repeats", 3, 9, 5, step=2,
                                help="Odd repeat counts help reduce timing noise.")
        fixed_pattern = st.text_input(
            "Corpus-scale query pattern",
            value="algorithm",
            help="Used for the corpus-scale study. Choose a pattern that occurs in your active corpus to measure a match scenario.",
        )
        scenario_cols = st.columns(2)
        run_text = scenario_cols[0].checkbox("Run corpus-scale study", value=True)
        run_patterns = scenario_cols[1].checkbox("Run pattern-length study", value=True)
        st.caption("Active-corpus runs repeat your indexed text to the selected length. Controlled-fixture runs generate a deterministic text with known query hits. Timings are local and vary by machine load.")
    if not run_text and not run_patterns:
        st.info("Select at least one experiment before starting the run.")
        return

    if st.button("Run selected experiments", type="primary"):
        st.session_state.pop("benchmark_result", None)
        scale_sizes = {
            "100 KB": [1_024, 5_120, 10_240, 51_200, 102_400],
            "500 KB": [1_024, 5_120, 10_240, 51_200, 102_400, 512_000],
            "1 MB": [1_024, 5_120, 10_240, 51_200, 102_400, 512_000, 1_048_576],
        }[max_text]
        try:
            if not fixed_pattern.strip():
                raise ValueError("Enter a non-empty query pattern.")
            corpus_text = "\n".join(
                document.original_text for document in engine.documents
            )
            source_text = corpus_text if source_mode == "Active corpus" else None
            with st.spinner("Running controlled measurements…"):
                text_rows = (
                    benchmark_text_sizes(
                        text_sizes=scale_sizes,
                        pattern=fixed_pattern,
                        repeats=repeats,
                        source_text=source_text,
                    )
                    if run_text else []
                )
                pattern_rows = (
                    benchmark_pattern_sizes(
                        text_size=scale_sizes[-1],
                        pattern_sizes=pattern_sizes,
                        repeats=repeats,
                        source_text=source_text,
                    )
                    if run_patterns and pattern_sizes else []
                )
                bloom_result = benchmark_bloom_filter(
                    "algorithm data structures search indexing performance",
                    ["algorithm", "structures", "missingxyz", "quantumxyz"],
                    repeats=repeats,
                )
            st.session_state["benchmark_result"] = {
                "text_rows": text_rows,
                "pattern_rows": pattern_rows,
                "bloom_result": bloom_result,
                "max_text": max_text,
                "source_mode": source_mode,
                "query_pattern": fixed_pattern,
                "repeats": repeats,
                "run_time": datetime.now().astimezone().strftime("%Y-%m-%d %H:%M %Z"),
            }
        except ValueError as error:
            st.error(str(error))
    result = st.session_state.get("benchmark_result")
    if not result:
        st.markdown(
            '<div class="evidence-note">Recommended workflow: run the same experiment more than once, compare growth trends, and report hardware and runtime context with your observations.</div>',
            unsafe_allow_html=True,
        )
        return
    text_rows = result["text_rows"]
    pattern_rows = result["pattern_rows"]
    st.markdown('<div class="section-kicker">Run summary</div>', unsafe_allow_html=True)
    summary = st.columns(4)
    summary[0].metric("Largest text", result["max_text"])
    summary[1].metric("Median samples", result["repeats"])
    summary[2].metric("Position agreement", "100%" if all(
        row["positions_agree"] for row in text_rows + pattern_rows
    ) else "Review")
    summary[3].metric("Completed at", result["run_time"])
    st.caption(f"Source: {result['source_mode']} · Fixed query: “{result['query_pattern']}” · Agreement means both algorithms returned identical match positions.")
    st.caption(f"Runtime environment: Python {platform.python_version()} · {platform.system()} {platform.release()}")

    frames = []
    if text_rows:
        frame = pd.DataFrame(text_rows)
        frame.insert(0, "experiment", "corpus_scale")
        frames.append(frame)
        st.markdown('<div class="section-kicker">Study 01 · Corpus scale</div>', unsafe_allow_html=True)
        st.caption("Pattern held constant while text length increases. Runtime is reported as the median of repeated runs.")
        _plot_algorithm_times(text_rows, "text_size")
        display = frame.rename(columns={"text_size": "Text characters", "pattern_size": "Pattern characters", "kmp_time": "KMP median (s)", "rabin_karp_time": "Rabin–Karp median (s)", "kmp_comparisons": "KMP comparisons", "hash_comparisons": "Hash comparisons", "character_verifications": "Character verifications", "positions_agree": "Positions agree"})
        st.dataframe(display, hide_index=True, use_container_width=True)
    if pattern_rows:
        frame = pd.DataFrame(pattern_rows)
        frame.insert(0, "experiment", "pattern_length")
        frames.append(frame)
        st.markdown('<div class="section-kicker">Study 02 · Pattern length</div>', unsafe_allow_html=True)
        st.caption("Corpus held constant while generated probe-pattern length changes. This isolates the pattern-length input variable.")
        _plot_algorithm_times(pattern_rows, "pattern_size")
        display = frame.rename(columns={"text_size": "Text characters", "pattern_size": "Pattern characters", "kmp_time": "KMP median (s)", "rabin_karp_time": "Rabin–Karp median (s)", "kmp_comparisons": "KMP comparisons", "hash_comparisons": "Hash comparisons", "character_verifications": "Character verifications", "positions_agree": "Positions agree"})
        st.dataframe(display, hide_index=True, use_container_width=True)
    if frames:
        export_frame = pd.concat(frames, ignore_index=True)
        export_frame.insert(1, "source", result["source_mode"])
        export_frame.insert(2, "largest_text_setting", result["max_text"])
        export_frame.insert(3, "median_repeats", result["repeats"])
        export_frame.insert(4, "fixed_query", result["query_pattern"])
        export_frame.insert(5, "run_time", result["run_time"])
        export_frame.insert(6, "python_version", platform.python_version())
        export_frame.insert(7, "operating_system", platform.system())
        st.download_button(
            "Download measurements (CSV)",
            export_frame.to_csv(index=False).encode("utf-8"),
            file_name="string_search_performance.csv",
            mime="text/csv",
        )
    st.markdown('<div class="section-kicker">Interpretation guide</div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="evidence-note">Compare the shape of the timing curves and the operation counts. Small runtime differences can be affected by interpreter, hardware, and background load; use repeated medians and avoid claiming one algorithm is universally faster from a single run.</div>',
        unsafe_allow_html=True,
    )
    st.markdown('<div class="section-kicker">Supporting component · Bloom Filter</div>', unsafe_allow_html=True)
    st.dataframe(pd.DataFrame([result["bloom_result"]]), hide_index=True, use_container_width=True)


def render_about() -> None:
    st.markdown(
        '<div class="eyebrow">Methodology</div>'
        '<div class="page-title">Methodology & Algorithms</div>'
        '<div class="page-subtitle">How the study is measured and how each technique fits the retrieval workflow.</div>',
        unsafe_allow_html=True,
    )
    st.markdown('<div class="section-kicker">Measurement protocol</div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="surface-card"><b>Controlled comparisons</b><br>'
        '<span class="result-stat">Hold one input variable constant while changing the other · run each algorithm repeatedly and report median time · record operation counts and match totals · verify identical result positions before interpreting performance.</span><br><br>'
        '<b>Practical reading</b><br><span class="result-stat">Use Trie for term-prefix discovery, KMP for predictable exact scans, and Rabin–Karp when rolling hashes or many candidate patterns are useful. Select based on query shape and measured workload rather than a single runtime value.</span></div>',
        unsafe_allow_html=True,
    )
    explanations = {
        "Trie": (
            "Used for prefix search and autocomplete by traversing characters."
        ),
        "KMP": (
            "Uses the LPS table to avoid unnecessary character comparisons."
        ),
        "Rabin-Karp": (
            "Uses a rolling hash to identify possible pattern matches."
        ),
        "Bloom Filter": (
            "Quickly eliminates queries that are definitely absent before "
            "expensive pattern matching."
        ),
    }
    st.markdown('<div class="section-kicker">How each component works</div>', unsafe_allow_html=True)
    detail_columns = st.columns(2)
    for index, (name, explanation) in enumerate(explanations.items()):
        with detail_columns[index % 2].expander(name, expanded=True):
            st.write(f"**Purpose:** {explanation}")
            if name == "Trie":
                st.write(
                    "**Complexity:** Prefix traversal is O(P) plus output; "
                    "space is O(total stored characters)."
                )
                st.write(
                    "**Why used:** Efficient prefix search and autocomplete."
                )
            elif name == "KMP":
                st.write("**How it works:** Builds an LPS table and reuses it "
                         "after mismatches.")
                st.write("**Complexity:** Preprocessing O(m), search O(n), "
                         "total O(n+m), space O(m).")
                st.write(
                    "**Why used:** Exact matching without restarting scans."
                )
            elif name == "Rabin-Karp":
                st.write(
                    "**How it works:** Rolls a modular hash across each "
                    "window, then verifies collisions character by character."
                )
                st.write("**Complexity:** Average O(n+m), worst O(nm), "
                         "space O(1) auxiliary.")
                st.write("**Why used:** Hash-based comparison and measurable "
                         "collision verification.")
            else:
                st.write(
                    "**How it works:** Sets bits with multiple deterministic "
                    "hash functions; set bits mean possibly present only."
                )
                st.write("**Complexity:** Membership O(k), space O(m).")
                st.write(
                    "**Why used:** Reject definite term-level misses cheaply."
                )
    st.markdown('<div class="section-kicker">Complexity comparison</div>', unsafe_allow_html=True)
    st.dataframe(
        pd.DataFrame(
            [
                ["Trie", "Prefix search", "O(P) + output", "O(total chars)"],
                ["KMP", "Pattern search", "O(n+m)", "O(m)"],
                [
                    "Rabin-Karp",
                    "Pattern search",
                    "Average O(n+m), worst O(nm)",
                    "O(1)",
                ],
                ["Bloom Filter", "Membership check", "O(k)", "O(m)"],
            ],
            columns=[
                "Algorithm",
                "Main operation",
                "Time complexity",
                "Space",
            ],
        ),
        hide_index=True,
        use_container_width=True,
    )


def render_document_workspace(engine: SearchEngine) -> None:
    st.markdown('<div class="eyebrow">Corpus administration</div><div class="page-title">Document Workspace</div><div class="page-subtitle">Add text, TXT, PDF, and DOCX files to the persistent local corpus.</div>', unsafe_allow_html=True)
    with st.form("paste_document"):
        name = st.text_input("Document name", placeholder="research-notes.txt")
        content = st.text_area("Paste document text", height=150)
        submitted = st.form_submit_button("Add document")
    if submitted:
        if not name.strip() or not content.strip():
            st.error("Enter both a document name and text.")
        else:
            if not Path(name).suffix:
                name += ".txt"
            if Path(name).suffix.casefold() != ".txt":
                st.error("Pasted text documents must use a .txt name.")
            elif engine.add_document(name, content):
                st.success("Document indexed and saved.")
                st.rerun()
            else:
                st.info("A document with this name is already indexed.")
    uploads = st.file_uploader("Upload documents (10 MiB each)", type=["txt", "pdf", "docx"], accept_multiple_files=True)
    if uploads:
        for upload in uploads:
            try:
                added = engine.add_document(upload.name, extract_text(upload.name, upload.getvalue()))
                st.success(f"Indexed {upload.name}") if added else st.info(f"{upload.name} is already indexed")
            except (ValueError, UnicodeError) as error:
                st.error(f"{upload.name}: {error}")
    st.markdown('<div class="section-kicker">Indexed documents</div>', unsafe_allow_html=True)
    st.dataframe(pd.DataFrame([{"Name": d.name, "Characters": len(d.original_text), "Words": len(d.tokens)} for d in engine.documents]), use_container_width=True, hide_index=True)


def render_search_history() -> None:
    st.markdown('<div class="eyebrow">Persistent activity</div><div class="page-title">Search History</div>', unsafe_allow_html=True)
    store = Storage(PROJECT_ROOT / "data" / "stringlab.sqlite3")
    rows = [dict(row) for row in store.history()]
    if rows:
        frame = pd.DataFrame(rows)
        a, b, c = st.columns(3)
        a.metric("Searches", len(rows))
        b.metric("Successful", int((frame.match_count > 0).sum()))
        c.metric("Average time", format_runtime(float(frame.elapsed_seconds.mean())))
        st.dataframe(frame, use_container_width=True, hide_index=True)
        counts = frame.groupby("query", as_index=False).size().sort_values("size", ascending=False).head(10)
        st.bar_chart(counts.set_index("query"))
    else:
        st.info("Search activity will appear here after you run a query.")
    if st.button("Clear search history"):
        store.clear_history()
        st.rerun()


def main() -> None:
    st.set_page_config(
        page_title="String Search Performance Studio",
        page_icon="⌕",
        layout="wide",
    )
    inject_styles()

    try:
        engine = load_engine()
    except (OSError, ValueError) as error:
        st.error(f"Unable to load documents: {error}")
        return

    st.sidebar.markdown(
        '<div class="brand-mark">⌕</div>'
        '<div class="brand-title">STRINGLAB<br>Performance Studio</div>'
        '<div class="brand-subtitle">Micro Project 10 · DSA Research Workspace</div>',
        unsafe_allow_html=True,
    )
    sections = {
        "01  Overview": "Dashboard",
        "02  Documents": "Document Workspace",
        "03  Corpus Search": "Text Search",
        "04  Trie Explorer": "Autocomplete",
        "05  Algorithm Comparison": "Algorithm Comparison",
        "06  Bloom Filter Analysis": "Bloom Filter Analysis",
        "07  Benchmark Lab": "Benchmark / Performance",
        "08  Search History": "Search History",
        "09  Methodology": "About Algorithms",
    }
    selected = st.sidebar.radio("Navigate", tuple(sections), label_visibility="collapsed")
    st.sidebar.markdown(
        '<div class="sidebar-status"><span class="status-dot"></span>'
        '<b>LOCAL STUDY SESSION</b><br><span style="opacity:.72">Corpus index is active</span></div>',
        unsafe_allow_html=True,
    )
    render_document_uploader(engine)
    section = sections[selected]
    st.markdown(
        '<div class="study-banner"><span><b>PERFORMANCE STUDY</b> &nbsp; / &nbsp; String matching and retrieval techniques</span>'
        '<span>LIVE LOCAL WORKSPACE &nbsp; · &nbsp; SQLITE CORPUS</span></div>',
        unsafe_allow_html=True,
    )
    if section == "Dashboard":
        render_dashboard(engine)
    elif section == "Document Workspace":
        render_document_workspace(engine)
    elif section == "Autocomplete":
        render_autocomplete(engine)
    elif section == "Text Search":
        render_text_search(engine)
    elif section == "Algorithm Comparison":
        render_algorithm_comparison(engine)
    elif section == "Bloom Filter Analysis":
        render_bloom_analysis(engine)
    elif section == "Benchmark / Performance":
        render_benchmark(engine)
    elif section == "Search History":
        render_search_history()
    else:
        render_about()


if __name__ == "__main__":
    main()
