# StringLab: string matching & retrieval studio

**Micro Project 10: Performance Study of String Matching and Retrieval Techniques**

StringLab is a local-first information retrieval lab. It indexes your documents into a frequency-weighted
**Trie**, a **Bloom filter** and a **BM25 inverted index**, ranks results by relevance, and verifies every hit
with three exact matchers (**KMP**, **Rabin–Karp** and **Boyer–Moore–Horspool**) so you can see where each one does
less work. It also includes **Aho–Corasick** multi-pattern scanning, **fuzzy (Levenshtein) Trie search** and a
benchmark lab with CSV export.

![Architecture](docs/diagrams/architecture.svg)

Full diagrams (architecture, request sequence, module map, Trie, automaton): **[docs/ARCHITECTURE.md](docs/ARCHITECTURE.md)**

## What's new in this version

### Model upgrades
| Area | Before | Now |
| --- | --- | --- |
| Exact matching | KMP + Rabin–Karp | + **Boyer–Moore–Horspool** with window/skip counts; results trusted only when **all three agree** |
| Ranking | none (file order) | **Okapi BM25** over an incremental inverted index (k1 = 1.5, b = 0.75), with per-term score breakdown |
| Relevance search | phrase only | **Relevance mode**: rank documents by any of the query words |
| Autocomplete | alphabetical | + **frequency-ranked top-k** via bounded heap; prefix counts per node |
| Typos | "not found" | **Did-you-mean** from fuzzy Trie search (Levenshtein row per node, branch pruning) |
| Multi-pattern | none | **Aho–Corasick** automaton: one pass finds every pattern; compared against repeated KMP |
| Benchmarks | 2 algorithms | 3 algorithms, runtime **and** operation-count curves |
| Tests | 51 | **66** (new models cross-checked against brute force and the Levenshtein definition) |

### Frontend redesign
- A new visual system: deep ink sidebar, pale cyanotype page, and a highlighter yellow reserved for matches and the
  Trie path. Headings are set in Bricolage Grotesque, body text in Public Sans, and strings in IBM Plex Mono.
- **Live Trie diagram**: your prefix path is highlighted, whole words are double-ringed, and hidden branches are
  shown as `+n`. Depth and breadth are adjustable, and hovering a node shows its counts.
- **Aho–Corasick automaton diagram** with goto edges and dashed failure links.
- **KMP prefix-function table** and **Horspool shift table** drawn for any pattern.
- **Bloom filter bit strip** showing where a word's hash positions land and which bits rule it out.
- **System architecture diagram** in the app and in `docs/diagrams/`.
- Interactive Altair charts throughout. The layout is responsive down to phone width, with visible keyboard focus
  and support for reduced motion.

All diagrams are pure-Python SVG (`ui/diagrams.py`), so there is no Graphviz or JavaScript dependency.

## Run locally

Requires Python 3.10+.

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1          # macOS/Linux: source .venv/bin/activate
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

Open the address Streamlit prints (usually `http://localhost:8501`). Run the tests with `python -m pytest`.

## Suggested demonstration

1. **Overview**: see the live specimen, where three algorithms find the same word with different amounts of work.
2. **Search**: try `rolling hash`, then a typo such as `serch` to get suggestions. Switch to *Relevance* and try
   `fuzzy edit distance trie`.
3. **Trie explorer**: try `se`, `al` and `data`. Raise *Levels below prefix* to grow the diagram.
4. **Multi-pattern scan**: the default `hash, has, search, arch, trie` shows overlapping patterns sharing states.
5. **Algorithm internals**: try `abracadabra` to see a rich LPS table and Horspool's skips.
6. **Benchmark lab**: run both studies, then download the CSV for your report.
7. **How it works**: architecture, pipeline and complexity reference.

## Project structure

```text
app.py                  Streamlit pages
ui/theme.py             Design tokens + CSS
ui/diagrams.py          SVG renderers: Trie, Aho–Corasick, LPS, shift table, Bloom strip, architecture
algorithms/             trie, kmp, rabin_karp, boyer_moore, aho_corasick, bloom_filter
core/search_engine.py   Pipeline: Bloom screen → BM25 rank → 3-way exact verification; fuzzy, top-k, multi-pattern
core/ranking.py         BM25 inverted index
core/benchmark.py       Text-size / pattern-length experiments
core/ingestion.py       Guarded TXT/PDF/DOCX extraction
core/storage.py         SQLite documents + search history
docs/                   ARCHITECTURE.md (Mermaid) + diagrams/*.svg
tests/                  66 unit and integration tests
```

## Experimental method

Text-size runs hold the pattern constant while text grows from 1 KB to the selected maximum; pattern-length runs
hold the text constant. Each algorithm is timed separately with `time.perf_counter()` and the median of an odd
number of runs is reported. Operation counts (character comparisons, hash comparisons plus verifications, Horspool
windows) are deterministic and more reliable than wall-clock time for explaining *why* curves differ.

## Scope and limitations

This is a local academic prototype. SQLite is unencrypted and single-user, so treat it as sensitive if your
documents are. PDF extraction needs embedded text (no OCR). Timings are in-process Python. Phrase search is exact
substring matching; relevance mode ranks by individual words.
