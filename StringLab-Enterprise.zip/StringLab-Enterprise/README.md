# String Search Performance Studio

**Micro Project 10 — Performance Study of String Matching and Retrieval Techniques**

An interactive, local-first information retrieval application for exploring Trie-based prefix retrieval and measuring KMP and Rabin–Karp. It includes a SQLite corpus and search history, guarded TXT/PDF/DOCX ingestion, exact search, benchmark experiments, and CSV measurements.

## Research alignment

| Project objective | Application feature |
| --- | --- |
| Formulate tests for different text lengths and pattern characteristics | Benchmark Lab varies corpus size and pattern length, with a selectable query and repeat count |
| Develop KMP and Rabin–Karp experiments with Trie-based retrieval | Corpus Search uses KMP and Rabin–Karp; Trie Explorer provides indexed prefix suggestions |
| Derive complexity and performance measures | Results include median runtime, comparison counts, hash checks, character verifications, and position agreement |
| Establish when each technique is suitable | Algorithm Comparison and Methodology explain roles, complexity, and measurement limitations |

## What it does

- Indexes sample `.txt` files plus persistent SQLite documents for exact search and Trie autocomplete.
- Accepts pasted text and bounded TXT/PDF/DOCX uploads (10 MiB per file; PDFs limited to 500 pages).
- Persists document text and search metadata in `data/stringlab.sqlite3`; the database is local and excluded from Git.
- Tracks query, timestamp, result count, elapsed time, algorithm label, and corpus size in Search History. Document text is not written to application logs.
- Shows exact match positions and surrounding text, with KMP and Rabin–Karp agreement validation.
- Benchmarks increasing text sizes and pattern lengths using repeated median timings.
- Runs experiments against either the active document corpus or a deterministic controlled fixture.
- Exports measured benchmark rows as CSV for analysis and project reporting.
- Demonstrates a Bloom Filter as an optional term-level pre-filter; a positive result is always verified by exact matching.

## Run locally

Requires Python 3.10 or newer.

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

Then open the local address printed by Streamlit, usually `http://localhost:8501`.

On macOS/Linux, activate the environment with `source .venv/bin/activate`.

## Recommended demonstration

1. Open **Overview** and review the indexed corpus profile.
2. Use **Trie Explorer** with prefixes such as `alg`, `data`, or `search`.
3. Search for `algorithm`, `data structures`, or `rolling hash` in **Corpus Search**. Confirm that both algorithms return the same positions.
4. In **Benchmark Lab**, choose **Active corpus**, set the query to a term present in the corpus, and run the corpus-scale experiment.
5. Run the pattern-length study and download the CSV. Include the selected input sizes, repeat count, and runtime environment in the report.
6. Use **Algorithm Comparison** and **Methodology** to discuss complexity and suitability.

## Experimental method

Corpus-scale runs hold the query pattern constant while text length increases from 1 KB to the selected maximum. Pattern-length runs hold text length constant while probe-pattern length changes. The active-corpus option repeats the combined corpus to create an exact requested size; the controlled fixture provides deterministic text with known pattern occurrences. Each algorithm is timed separately with `time.perf_counter()`, and the app reports the median of an odd number of runs.

Measured values depend on Python, hardware, and background load. Compare growth trends and operation counts, repeat experiments, and avoid treating a single timing run as proof that one algorithm is universally faster. KMP and Rabin–Karp must agree on match positions for each input.

## Algorithms

- **Trie:** prefix lookup in `O(P)` plus returned suggestions; stores edges for indexed characters.
- **KMP:** exact matching in `O(n + m)` time with `O(m)` preprocessing space.
- **Rabin–Karp:** rolling-hash matching, average `O(n + m)` and worst-case `O(nm)`; verifies candidate matches to handle collisions.
- **Bloom Filter:** `O(k)` preliminary term membership; can rule out a term but cannot prove one is present.

## Project structure

```text
app.py                 Streamlit interface
algorithms/            Trie, KMP, Rabin–Karp, Bloom Filter
core/                  Corpus indexing, search, and experiments
data/sample_documents/ Demonstration corpus
tests/                 Automated unit and integration tests
utils/                 Timing helpers
```

## Scope and limitations

This is a local academic prototype. SQLite stores the corpus without encryption or multi-user access controls; treat its database as sensitive if uploaded documents are sensitive. PDF extraction depends on embedded text and does not perform OCR. Benchmarks measure in-process Python algorithms, not production-service or distributed-load behavior. Search currently returns exact substring matches; Trie retrieval is specifically for prefixes.

## Architecture and storage

`app.py` is the Streamlit presentation layer. `core/search_engine.py` coordinates matching and the Trie/Bloom indexes; `core/document_manager.py` prepares corpus text; `core/ingestion.py` validates and extracts supported uploads; `core/storage.py` owns SQLite persistence; `core/benchmark.py` runs controlled experiments. `algorithms/` contains the four research structures and algorithms. SQLite schema initialization is automatic and idempotent.

The database uses SHA-256 content digests to suppress identical-content ingestion and indexes document names and search timestamps. Search history stores query metadata, not document contents. The database is created on first run under `data/`.
